import { data, normalize } from './model.js?v=928c5f0e19';
const SLUG = 'meros';
const $ = s => document.querySelector(s),
  $$ = s => [...document.querySelectorAll(s)];
const storageKey = SLUG + '-state-v1';
let memory = [],
  persistent = true;
function read() {
  if (!persistent) return memory;
  try {
    const raw = localStorage.getItem(storageKey),
      parsed = raw === null ? [] : JSON.parse(raw);
    if (!Array.isArray(parsed)) throw Error('Invalid stored list');
    memory = normalize(parsed);
    return memory;
  } catch {
    persistent = false;
    $('#status').textContent =
      'Saqlangan ma’lumot o‘qilmadi. Asl nusxa o‘zgartirilmaydi; yangi tanlov faqat shu tabda qoladi.';
    return memory;
  }
}
function commit(ids) {
  memory = normalize(ids);
  if (!persistent) return memory;
  try {
    localStorage.setItem(storageKey, JSON.stringify(memory));
  } catch {
    persistent = false;
    $('#status').textContent =
      'Saqlash cheklangan. Tanlov faqat shu ochiq tabda qoladi; sahifani yangilashda yo‘qolishi mumkin.';
  }
  return memory;
}
function toggle(id) {
  const ids = read();
  return commit(ids.includes(id) ? ids.filter(x => x !== id) : [...ids, id]);
}
function download(name, text, type = 'text/plain;charset=utf-8') {
  const url = URL.createObjectURL(new Blob(['\ufeff' + text], { type })),
    a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}
let opener, openedId;
function openDialog(button) {
  opener = button;
  openedId = button.dataset.read;
  $('#reader').showModal();
}
$$('[data-close]').forEach(b => b.addEventListener('click', () => $('#reader').close()));
$('#reader')?.addEventListener('close', () => {
  const target = opener?.isConnected
    ? opener
    : document.querySelector('[data-read="' + openedId + '"]') || $('#saved-toggle');
  target?.focus();
});
window.addEventListener('storage', e => {
  if (e.key === storageKey || e.key === null) {
    const active = document.activeElement;
    const attribute = ['data-save', 'data-read', 'data-lesson'].find(a => active?.hasAttribute(a));
    const value = attribute ? active.getAttribute(attribute) : null;
    render();
    if ($('#reader')?.open && typeof syncSave === 'function') syncSave();
    if (attribute && !active.isConnected) {
      const next = $$('[' + attribute + ']').find(b => b.getAttribute(attribute) === value && !b.disabled);
      const target = next || $('#saved-toggle') || $('#lesson-title');
      if (target) {
        if (!next && target.id === 'lesson-title') target.setAttribute('tabindex', '-1');
        target.focus({ preventScroll: true });
      }
    }
  }
});
let category = 'all',
  savedOnly = false,
  selected;
function render() {
  const ids = read(),
    items = data.filter(
      p => (category === 'all' || p.category === category) && (!savedOnly || ids.includes(p.id))
    );
  $('#saved-count').textContent = ids.length;
  $('#saved-toggle').setAttribute('aria-pressed', savedOnly);
  $('#exhibit-count').textContent = items.length + ' lavha / fotografik ekspozitsiya';
  $('#empty').hidden = !!items.length;
  $('#export').disabled = !ids.length;
  $('#exhibit-list').innerHTML = items
    .map(
      (p, i) =>
        `<article class="exhibit" id="work-${p.id}"><span class="exhibit-number">${String(data.indexOf(p) + 1).padStart(2, '0')}</span><button class="exhibit-image" data-read="${p.id}" aria-label="${p.name}: tafsilot"><img src="images/${p.image}" width="1000" height="700" alt="${p.name}"></button><div class="exhibit-copy"><span class="eyebrow">${p.tag}</span><h3>${p.name}</h3><p>${p.text}</p><button class="btn" data-save="${p.id}" aria-label="${p.name}: ${ids.includes(p.id) ? 'Kolleksiyada, olib tashlash' : 'Kolleksiyaga olish'}" aria-pressed="${ids.includes(p.id)}">${ids.includes(p.id) ? '✓ Kolleksiyada' : 'Kolleksiyaga olish +'}</button></div></article>`
    )
    .join('');
}
document.addEventListener('click', e => {
  const b = e.target.closest('button');
  if (!b) return;
  if (b.dataset.filter) {
    category = b.dataset.filter;
    $$('[data-filter]').forEach(x => x.setAttribute('aria-pressed', x === b));
    render();
  }
  if (b.dataset.save) {
    const id = b.dataset.save;
    toggle(id);
    render();
    (document.querySelector('[data-save="' + id + '"]') || $('#saved-toggle')).focus();
    if (persistent) $('#status').textContent = 'Shaxsiy kolleksiya yangilandi.';
  }
  if (b.dataset.read) {
    selected = b.dataset.read;
    const p = data.find(p => p.id === selected);
    $('#reader-title').textContent = p.name;
    $('#reader-body').innerHTML =
      `<img src="images/${p.image}" alt="${p.name}"><p>${p.text}</p><p><a href="${p.source}">Uzbekistan Travel — rasmiy ma’lumot ↗</a></p><p><a href="CREDITS.md">Surat muallifi va litsenziyasi ↗</a></p>`;
    syncSave();
    openDialog(b);
  }
});
function syncSave() {
  const on = read().includes(selected);
  $('#reader-save').setAttribute('aria-pressed', on);
  $('#reader-save').textContent = on ? '✓ Kolleksiyada' : 'Kolleksiyaga olish +';
}
$('#reader-save').addEventListener('click', () => {
  toggle(selected);
  syncSave();
  render();
});
$('#saved-toggle').addEventListener('click', () => {
  savedOnly = !savedOnly;
  render();
});
$('#export').addEventListener('click', () =>
  download(
    'meros-kolleksiya.txt',
    'MEROS — mustaqil fotografik ekspozitsiya\n' +
      read()
        .map(id => {
          const p = data.find(p => p.id === id);
          return p.name + '\n' + p.source;
        })
        .join('\n\n')
  )
);
render();
$$('.poster-index a').forEach(a =>
  a.addEventListener('click', () => {
    category = 'all';
    savedOnly = false;
    $$('[data-filter]').forEach(b => b.setAttribute('aria-pressed', b.dataset.filter === 'all'));
    render();
  })
);
