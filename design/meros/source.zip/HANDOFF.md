# HANDOFF — Meros

## Snapshot
- Manba: https://azizbeksafarov.github.io/design/meros/
- Paket sanasi: 2026-10-15; source fingerprint: c9c27359b42cc4726cd4224da960acba4217eb592104748fa540189dffb6cbbd
- Holat: oldindan tayyorlangan demo. Hozirgi biletga moslashtirish hali bajarilmagan.
- Baseline QA: ZIP ichidagi site/QA-REPORT.md; Bloom uchun 4 model testi va build o‘tgan. Bu yangi o‘zgarishlar uchun avtomatik dalil emas.

## Hozirgi topshiriq
- Bilet: CURRENT-TASK.md ga yoziladi.
- Qolgan vaqt va ishdagi local URL: hali kiritilmagan.
- Bajarilgan talablar: hali kiritilmagan.
- O‘zgargan fayllar: hali kiritilmagan.
- O‘tkazilgan testlar va natija: hali kiritilmagan.
- Ochiq xato / cheklov: demo browser-local; haqiqiy backend/yuborish yo‘q.
- Keyingi amal: biletni qabul sinovlariga aylantirish va existing previewni ochish.

## Keyingi AIga topshirish
CURRENT-TASK.md → ushbu HANDOFF.md → AGENTS.md → faqat tegishli source fayllarini o‘qi. Tekshirilmagan bandni bajarilgan deb belgilama. Har katta bosqichdan keyin ushbu holatni yangila.
