# Meros — independent sector identity

Kuratorlik ko‘rgazmasi. Alfa Slab One katta afisha; Archivo 650–800 barcha xizmat, indeks va tugma; Literata faqat uzun asar sharhi. Ultramarin, limon, oq. Indeks — yirik raqam + to‘liq bosiladigan qalin blok; nozik serif satr va mayda chiziqli havola emas. O‘tkir burchakli plakat tili, asimmetrik foto va navbat almashadigan asar/sharh. Sayohat pill kartalari yoki showroom savdo tizimini ko‘chirma.

Standalone HTML/CSS/JavaScript; no npm install. Preview: `python -m http.server 8080 --bind 127.0.0.1` here. Test: `node --test *.test.mjs`.

index.html: markup and IDs. style.css: local fonts and accessible mechanics. layout.css: this sector’s full art direction and responsive rules. app.js: existing flows, storage and focus. model.js: data/validation. Read CREDITS.md and bundled font licenses. Preserve model IDs and validated storage keys when changing layout.

In a competition copy, edit these files directly; no build step is needed. (The publishing repository regenerates its gallery copy with its own scripts, which are not part of a competition copy.)


At ZIP root run node serve.mjs. Editable files are site/. AI working rules and reading order: AGENTS.md.

Paket tarkibi: START-HERE.md. Codex bilan ishlash: ZAXIRA/CODEX.md. AI ishlamasa, AI’siz yo‘l: ZAXIRA/ZAXIRA.md.
