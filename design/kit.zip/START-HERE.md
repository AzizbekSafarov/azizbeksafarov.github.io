# Azizbek — tanlov dizaynlarini yangi AI bilan ishlatish

2026-10-16. Faol dizaynlar: 9. Faqat tanlangan dizaynning sahifasi yoki ai.md faylini o‘qi. Unda tanlov konteksti, visual contract, run, haqiqiy source, oldingi tuzatishlar va xatoni tekshirish/tuzatish tartibi bor.

- [Orbita](https://azizbeksafarov.github.io/design/orbita/) — /design/orbita/; Qorong‘i texnik observatoriya: Chakra Petch, monospace yozuv, orbital asbob oynasi va vertikal missiya registri.
- [Nashr](https://azizbeksafarov.github.io/design/nashr/) — /design/nashr/; Bosma gazeta: Newsreader masthead, PT Serif maqola, Archivo xizmat yozuvi, oq-qora suratlar va zich tahririy ustunlar.
- [Hisob](https://azizbeksafarov.github.io/design/hisob/) — /design/hisob/; Ma’lumotlar ish stoli: Public Sans xizmat interfeysi, ixcham Plex raqamlari, birlashgan ko‘rsatkich bandi va aniq jadval.
- [Ziyo](https://azizbeksafarov.github.io/design/ziyo/) — /design/ziyo/; Rangli ta’lim ustaxonasi: yumshoq Bree Serif, bosqichli dars yo‘li, ishlaydigan ko‘rgazmali misol va olcha rangli mashq daftari.
- [Meros](https://azizbeksafarov.github.io/design/meros/) — /design/meros/; Yorqin ko‘rgazma afishasi: ultramarin va limon, og‘ir Alfa Slab One, Literata sharhlari va navbatma-navbat joylashgan asarlar.
- [Samar](https://azizbeksafarov.github.io/design/samar/) — /design/samar/; Sayohat qaydlari va buklama atlas: Lora kitob serifi, qum rangli shartli xarita, moviy belgilar va chipta kabi kun rejasi.
- [Forma](https://azizbeksafarov.github.io/design/forma/) — /design/forma/; Interyer jurnali kabi showroom: nozik Italiana serifi, uch xil balandlikdagi mahsulotlar, sokin Manrope va material fotosuratlari.
- [Bloom · Material Design 3](https://azizbeksafarov.github.io/design/bloom/) — /design/bloom/; Rasmiy Material Web komponentlari, Material Symbols va dinamik rang tizimi. Ishlaydigan loyiha maydoni.
- [Yuksal · SI](https://azizbeksafarov.github.io/design/si/) — /design/si/; Oq asosiy fon, O‘zbekistonning moviy va yashil aksentlari; yarim oy va 12 yulduzli zarrachali bayroq. SI.gov harakat mexanikasi, serif va jonli shakl almashishi.

- [Markaziy kontekst](https://azizbeksafarov.github.io/ai.md)
- [Qisqa tanlov konteksti](https://azizbeksafarov.github.io/design/handoff/competition.md)
- [Barcha yig‘ilgan tanlov ma’lumoti](https://azizbeksafarov.github.io/ustoz/ai.md)
- [Tanlangan 9 source ZIP va tanlov matnlari](https://azizbeksafarov.github.io/design/kit.zip)
- [Machine-readable faol katalog](https://azizbeksafarov.github.io/design/catalog.json)
- [Sifat standarti](https://azizbeksafarov.github.io/design/DESIGN-STANDARD.md)

Foydalanuvchi bilet, vaqt va joydagi talabni beradi. AI tanlangan uslubni saqlab mavzuga moslashtiradi, amallarni tekshiradi, xatoni tuzatib qayta sinaydi va HANDOFF.md ga holatni yozadi. Link doimiy xotira yoki avtomatik bajarishni kafolatlamaydi.
