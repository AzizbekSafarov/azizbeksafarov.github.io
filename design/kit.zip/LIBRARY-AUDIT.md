# Ochiq bosh qarorgoh auditi — 2026-10-18

Maqom: shu sanadagi kod, hujjat va paketlar tekshiruvi. Keyingi tahrirga avtomatik kafolat emas. Audit .io repozitoriysi va uning to‘qqiz dizayn paketiga tegishli. Tanlov mahsulotining hali yaratilmagan backend integratsiyasi hamda alohida maxfiy omborning ichki xavfsizligi bu auditda sinalmagan.

## Topildi va tuzatildi

1. **ZIP konteksti saytdan ortda qolgan edi.** Ish tartibi, arxitektura va API konteksti endi barcha to‘qqiz source.zip hamda umumiy kit.zip ichida bor. WORKFLOW.md, PROJECT-STATUS.json, ARCHITECTURE.md, API-GUIDE.md va API-EVIDENCE.json saytdagi shu nusxalardan olinadi.
2. **Dizayndan bevosita kirgan AI yangi qarorlarni ko‘rmay qolishi mumkin edi.** Har bir dizayn brief’i, uning qisqa alias’i va yaratiladigan CURRENT-TASK.md joriy ish tartibi hamda Render + Supabase rejasiga yo‘naltiradi. Backend haqidagi eski shartli jumlalar foydalanuvchining amaldagi qaroriga moslandi.
3. **Bir saqlash yo‘riqnomasida o‘chirilgan generator ko‘rsatilgan edi.** HANDOFF-README.md endi amaldagi build_hq.py / build_handoff.py va BUILD-GUIDE.md’ga yo‘naltiradi. Ishlamaydigan eski generator amaliy qadam sifatida qolmagan.
4. **Tekshiruv faqat tanlangan HTML sahifalar bilan cheklangan edi.** verify_site.py barcha 51 HTML fayl, alias, redirect va boshqa sahifadagi anchorlarni ham tekshiradi. Vite development entry o‘z loyiha/public yo‘llari bilan alohida hisoblanadi; uning internetdagi ishlaydigan preview’i dist/ ichida.
5. **Paket o‘z ichida mos, lekin source’dan eskirgan bo‘lsa o‘tishi mumkin edi.** verify_handoff.py endi barcha paket runtime fayllari va umumiy kontekstni amaldagi manba bilan bayt darajasida solishtiradi.
6. **README’da eski band soni va tekshiruv qamrovi qolgan edi.** Qat’iy xavf soni olib tashlandi. Oldingi QA hujjatlari sanali baseline sifatida belgilandi; joriy loyiha tekshirilgan deb talqin qilinmaydi.
7. **Git ignore himoyasi tor edi.** Haqiqiy .env, node_modules, vaqtinchalik fayllar va loglar uchun ignore qo‘shildi; GitHub Pages uchun kerakli dist va source paketlari saqlandi. .env.example istisno bo‘lib qoladi.

## Dalillar va amaliy chegaralar

- **614 avtomatik test: PASS.** Bunda model, kombinatsiya va DOM/storage fixture testlari bor; ularning hammasi brauzer testi emas. `node design/qa/run.mjs`.
- **51 HTML va 721 mahalliy murojaat: PASS.** 51 JS/CSS resurs grafigi tekshirildi. `python -B design/verify_site.py`. Alohida /ustoz/ loyihasidagi manzillar bu mahalliy tekshiruvga kirmaydi.
- **205 Markdown murojaati:** tekshirilgan mahalliy yoki shu HQ domeniga tegishli manzillarda yo‘q fayl topilmadi; alohida /ustoz/ nusxalari bundan tashqari.
- **To‘qqiz source ZIP va kit:** hashlar, tarkib, alias matni, readable source eksportlari hamda amaldagi runtime/kontekst bilan moslik tekshiriladi. `python -B design/verify_handoff.py`.
- **Toza papkalarga ochilgan ZIP’lar:** ichidagi 488 test PASS (614 testning bir qismi). Har birining `node serve.mjs` preview’i HTTP 200 qaytardi va paket tashqarisiga chiqishga urinish rad etildi. Bu shu kompyuterdagi yangi papka sinovi; yangi jismoniy PC’da sinalgan deb talqin qilinmaydi. [Dalil](https://azizbeksafarov.github.io/design/qa/audit-20261018-portable.json).
- **45 brauzer o‘lchovi:** 6 asosiy bo‘lim + 9 demo, har biri 320/768/1280 CSS px. Hujjat bo‘ylab ortiqcha gorizontal scroll yoki yuklangan rasmlarda buzilgan manba topilmadi. Bu barcha qurilma/brauzerlar yoki to‘liq accessibility auditi emas. Dalil: [audit-20261018-browser.json](https://azizbeksafarov.github.io/design/qa/audit-20261018-browser.json).
- **To‘qqiz demo amali:** Forma savat jami va Escape/fokus; Ziyo to‘g‘ri javob/progress; Orbita kuzatuv; Nashr/Meros dialoglari; Hisob apostrofli qidiruvi; Samar reja; Yuksal reja; Bloom palitra va saqlash. HQ qidiruv/bo‘sh holat/tanlash, topshiriqni nusxalash va CURRENT-TASK.md yuklash ham brauzerda bajarildi.
- **Npm audit:** Bloom lockfile’ining production va development dependency’larida tekshiruv payti ma’lum zaiflik qaytarilmadi. Bu noma’lum zaiflik yo‘q degani emas.
- **Ochiq ma’lumot nazorati:** joriy public matnlar va ichma-ich ZIP’larda tanilgan provider kaliti, bot tokeni, private key va karta raqami andozalari tekshirildi. Material rang matematikasidagi kasr sonlar tekshirilib, karta bilan adashtirilmadi. `verify_public.py` qiymatlarni chiqarmasdan takrorlanadi. Git tarixidagi provider/bot/private-key andozalari bo‘yicha ham mos o‘zgarish topilmadi; tarixdagi barcha shaxsiy ma’lumot turlarining to‘liq ekspertizasi bajarilmadi.

## Joriy manba tartibi

Joriy foydalanuvchi topshirig‘i va loyiha CURRENT-TASK.md / HANDOFF.md → [markaziy ai.md](https://azizbeksafarov.github.io/ai.md) → [ish tartibi](https://azizbeksafarov.github.io/ish-tartibi/ai.md) va [holat](https://azizbeksafarov.github.io/ish-tartibi/status.json) → [arxitektura](https://azizbeksafarov.github.io/arxitektura/ai.md) / [API](https://azizbeksafarov.github.io/api/ai.md) → bitta tanlangan dizayn va uning source’i.

- /dezayn/SLUG/ai.md va /bloom/ai.md — mustaqil eski tahrirlar emas, kanonik dizayn brief’ining aynan bir xil yaratilgan nusxalari.
- Eski QA raqamlari/sanasi tarixiy tekshiruvni ko‘rsatadi. Ichki v2/v3 generator bosqichlari mustaqil faol dizayn emas; BUILD-GUIDE.md ularning vazifasini tushuntiradi. Isolated source ZIP’larda kutubxona generatorini qayta ishlatish shart emas.
- 2026-10-13 bosqichi va 120 daqiqalik mashq — tarixiy kontekst; bugungi bilet, natija yoki amaldagi vaqt deb olinmaydi.
- Render, UptimeRobot, tanlov Supabase loyihasi, Google OAuth va webhook hali rejalashtirilgan. API ulanish javoblari to‘liq mahsulot integratsiyasi o‘rnini bosmaydi. Backendning happy/failure/new-environment testlari real mahsulotda alohida bajariladi.

Aniqlangan xato dalil bilan, ehtimoliy xavf ssenariy sifatida yoziladi. Ko‘rsatma va tavsiya foydalanuvchining amaldagi topshirig‘ini almashtirmaydi.
