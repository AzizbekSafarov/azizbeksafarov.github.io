# Hozirgi tanlov topshirig‘i

- Biletning aynan matni: hali berilmagan.
- Foydalanuvchi va maqsad: biletdan olinadi.
- Majburiy funksiyalar: biletdan olinadi.
- Amaliy ish uchun haqiqiy qolgan vaqt: hali kiritilmagan.
- Joydagi vosita/internet/shablon talablari: tasdiqlanganini yozing.
- Tanlangan dizayn: Spark
