# Project context

Read AGENTS.md in this directory, then AI-BRIEF.md, CURRENT-TASK.md and HANDOFF.md before editing. User task and actual competition rules take priority. Communicate in Uzbek. Small context or limited usage: read ZAXIRA/ZAXIRA.md instead of the large context files.
