# Yuksal · SI — dizayn xaritasi

Foydalanuvchi kod yozmaydi va o‘zgarishni oddiy so‘z bilan aytadi. Bu fayl o‘sha so‘zni aniq fayl va amalga bog‘laydi. Qiymatlar shu paketdagi haqiqiy fayllardan olingan.

## Kimning so‘zi ustun

1. Foydalanuvchining aniq aytgani (rang, shrift, joylashuv, bo‘lim, matn) vizual kontraktdan ustun: darhol bajaring, “dizaynni saqlash kerak” deb rad etmang.
2. Bilet talabi va joydagi tashkilotchi ko‘rsatmasi hech qachon buzilmaydi; zid bo‘lsa, buni bir jumlada ayting va qaror so‘rang.
3. Aytilmagan hamma narsada shu dizaynning shrift, rang roli va tugma uslubi saqlanadi. Vizual kontrakt tasodifiy buzilishdan himoya qiladi, foydalanuvchini cheklamaydi.
4. O‘zgarishni butun saytga izchil qo‘llang: bitta tokenni o‘zgartirib, unga bog‘liq matn kontrasti (kamida 4.5:1), hover va tanlangan holatlarni ham tekshiring.

Build kerak emas: faylni saqlab, brauzerni yangilash yetarli.

## Foydalanuvchi aytsa

| So‘z | Qayerda | Nima qilinadi |
|---|---|---|
| “Rangni o‘zgartir”, “ko‘kroq qil” | “Asosiy ranglar” jadvali, `site/style.css` | Token yetmaydi: ko‘p rang to‘g‘ridan-to‘g‘ri yozilgan. Jadvaldagi qiymatni ko‘rsatilgan fayllarda birga almashtiring, keyin kontrastni tekshiring |
| “Shriftni almashtir”, “kattaroq yoz” | `site/style.css`, `@font-face` | Yangi shriftni loyihaga lokal qo‘shing; o‘lchamni sarlavha va matn darajalari bo‘yicha o‘zgartiring |
| “Matnni o‘zgartir”, “sarlavha boshqacha bo‘lsin” | `site/index.html`, `site/model.js` | Boshlang‘ich matn sahifada, takrorlanadigan kartalar ma’lumotda |
| “Rasmni almashtir” | `site/ (yangi `images/` papkasini oching)` | Faylni almashtiring, alt matnini yangilang, litsenziyani `CREDITS.md` ga yozing |
| “Yangi bo‘lim”, “yangi sahifa qo‘sh” | `site/index.html`, `site/app.js`, `site/style.css` | Mavjud bo‘lim naqshidan foydalaning, navigatsiyaga ulang, responsive holatini qo‘shing |
| “Bu bo‘limni olib tashla” | `site/index.html`, `site/app.js` | Bo‘limni, unga havolani va ishlatilmay qolgan kodni birga olib tashlang |
| “Forma qo‘sh”, “tekshiruv bo‘lsin” | `site/model.js`, `site/app.js` | Qoidani modelga, xabarni ekranga yozing; bo‘sh va noto‘g‘ri qiymatni sinang |
| “Saqlansin”, “yangilaganda yo‘qolmasin” | `site/app.js` | Storage kaliti versiyasi bilan saqlang, reload va boshqa tabda sinang |
| “Telefonda buzilyapti” | `site/style.css` | 390, 768 va 1366 px da ko‘ring, sababini tuzating |
| “Butunlay boshqa kayfiyat” | `site/style.css`, `site/style.css` | Avval tokenlar va shriftlarni o‘zgartiring; freymvorkni almashtirmang |
| “Hakam shu joyni o‘zgartirishni so‘radi” | yuqoridagi qatorlar | Eng kichik xavfsiz tahrirni qiling, shu oqimni qayta sinang (`ZAXIRA/JONLI-OZGARISH.md`) |

## Fayllar

| Fayl | Qator | Vazifasi |
|---|---|---|
| `site/app.js` | 250 | tugmalar, dialoglar, saqlash va eksport |
| `site/index.html` | 381 | sahifa tuzilishi, bo‘limlar va boshlang‘ich matn |
| `site/model.js` | 81 | namuna ma’lumotlar, tekshiruv va hisob-kitob |
| `site/motion.js` | 609 | zarrachali harakat va animatsiya |
| `site/style.css` | 2025 | rang tokenlari, shriftlar va komponentlar |

## Rang tokenlari

| Token | Hozirgi qiymat |
|---|---|
| `--navy` | `#062c35` |
| `--navy-deep` | `#041e26` |
| `--cream` | `#f8fcfb` |
| `--light` | `#e4f3ee` |
| `--accent` | `#0099b5` |
| `--green` | `#1eb53a` |
| `--flag-red` | `#ce1126` |
| `--blue` | `#71d9e6` |
| `--muted` | `#abcbd1` |
| `--line` | `#ffffff29` |

## Asosiy ranglar

Kodda eng ko‘p ishlatilgan to‘g‘ridan-to‘g‘ri qiymatlar. Rang o‘zgarishi saytda ko‘rinishi uchun shu qiymatlarni almashtiring.

| Rang | Marta | Fayllar |
|---|---|---|
| `#ffffff` | 6 | index.html, motion.js, style.css |
| `#3f6269` | 6 | style.css |
| `#168a43` | 5 | motion.js, style.css |
| `#0099b5` | 3 | motion.js, style.css |
| `#ce1126` | 3 | motion.js, style.css |
| `#062c35` | 3 | motion.js, style.css |
| `#1eb53a` | 2 | motion.js, style.css |
| `#007c92` | 2 | motion.js, style.css |
| `#f8fcfb` | 2 | style.css |
| `#88aeb4` | 2 | style.css |
| `#45cadd` | 2 | style.css |
| `#40646d` | 2 | style.css |
| `#a4cbd0` | 2 | style.css |
| `#59757d` | 1 | motion.js |

## Shriftlar

- Instrument Sans — `./instrument-0.woff2`
- Instrument Sans — `./instrument-1.woff2`
- Instrument Serif — `./instrument-2.woff2`
- Instrument Serif — `./instrument-3.woff2`
- Instrument Serif — `./instrument-4.woff2`
- Instrument Serif — `./instrument-5.woff2`

## Sahifa bo‘limlari

| Teg | id | Tavsif |
|---|---|---|
| `nav` | `—` | Sahifa bo‘limlari |
| `main` | `main` |  |
| `section` | `boshlanish` |  |
| `section` | `qarash` |  |
| `section` | `yondashuv` |  |
| `section` | `signal` |  |
| `section` | `tashabbuslar` |  |
| `section` | `reja` |  |
| `dialog` | `site-menu` |  |
| `nav` | `—` | Asosiy menyu |
| `dialog` | `initiative-dialog` |  |
