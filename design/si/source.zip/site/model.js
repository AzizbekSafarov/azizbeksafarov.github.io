export const initiatives = [
  {
    id: 'savod',
    title: 'SI savodxonligi',
    category: 'O‘rganish',
    description:
      'Sun’iy intellekt bilan ongli ishlashni o‘rganing. Savolni aniq yozish, manbani tekshirish va shaxsiy ma’lumotni asrashdan boshlang.',
    steps: [
      'O‘rganmoqchi bo‘lgan mavzuni bitta aniq savolga aylantiring.',
      'SI javobidagi asosiy fikrlarni ishonchli manba bilan solishtiring.',
      'O‘rganganingiz asosida o‘zingizning qisqa xulosangizni yozing.'
    ]
  },
  {
    id: 'lab',
    title: 'G‘oyalar laboratoriyasi',
    category: 'Yaratish',
    description:
      'Atrofingizdagi kichik muammo uchun sodda yechim yarating. Avval prototip, keyin foydalanuvchi fikri va yaxshilash.',
    steps: [
      'Kimning qaysi muammosini hal qilayotganingizni yozing.',
      'Yechimning eng kichik ishlaydigan variantini yarating.',
      'Bitta foydalanuvchida sinang va keyingi tuzatishni qayd eting.'
    ]
  },
  {
    id: 'ustoz',
    title: 'Ustoz bilan bir qadam',
    category: 'Hamkorlik',
    description:
      'Ishingiz haqida aniq fikr almashishga tayyorlaning. Bu yo‘nalish mustaqil mashq; mentor bilan haqiqiy uchrashuv bron qilinmaydi.',
    steps: [
      'Ishingizni ko‘rsatadigan bitta namuna tayyorlang.',
      'Javob olmoqchi bo‘lgan uchta aniq savol yozing.',
      'Olingan fikrni bajariladigan keyingi qadamga aylantiring.'
    ]
  },
  {
    id: 'ilm',
    title: 'Ilmga ochiq eshik',
    category: 'O‘rganish',
    description:
      'Savol, taxmin va dalil orasidagi farqni amalda ko‘ring. Kichik tajriba ham katta qiziqishning boshlanishi bo‘lishi mumkin.',
    steps: [
      'Tekshirish mumkin bo‘lgan savol va taxminni yozing.',
      'Kichik tajriba yoki ishonchli ochiq ma’lumot bilan tekshiring.',
      'Natija, cheklov va xulosani bitta sahifada tushuntiring.'
    ]
  }
];
export function validPlan(value) {
  return Array.isArray(value)
    ? [...new Set(value.filter(id => initiatives.some(item => item.id === id)))]
    : [];
}
export function parsePlan(raw) {
  try {
    return validPlan(JSON.parse(raw));
  } catch {
    return [];
  }
}
export function togglePlan(value, id) {
  const plan = validPlan(value);
  if (!initiatives.some(item => item.id === id)) return plan;
  return plan.includes(id) ? plan.filter(item => item !== id) : [...plan, id];
}
export function planText(value) {
  const items = validPlan(value).map(id => initiatives.find(item => item.id === id));
  return [
    'YUKSAL · SHAXSIY REJA',
    'Mustaqil mashq yo‘nalishlari. Haqiqiy ro‘yxatdan o‘tish emas.',
    '',
    ...items.flatMap((item, index) => [
      `${index + 1}. ${item.title}`,
      item.description,
      ...item.steps.map((step, i) => `   ${i + 1}) ${step}`),
      ''
    ])
  ].join('\n');
}
