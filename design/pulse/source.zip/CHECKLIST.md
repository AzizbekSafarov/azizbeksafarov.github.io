# Qabul tekshiruvi — Pulseboard

Bajarilgan deb faqat amalda tekshirilgan band belgilanadi.

- [ ] 7/30 kunlik davr → ko‘rsatkich va grafikning izchil o‘zgarishi.
- [ ] Jadval qidiruvi → natija/bo‘sh holat → aynan filtrlangan CSV; mobil jadvalning ichki scrolli.
- [ ] Haqiqiy biletning har majburiy talabi natijagacha ishlaydi.
- [ ] Bo‘sh/noto‘g‘ri qiymat va topilmagan natija tushunarli.
- [ ] 320/390, 768, 1024, 1440 px: yozuv va asosiy tugmalar kesilmaydi.
- [ ] Tugma oddiy paneldan farqlanadi; hover/pressed/focus va tanlangan holat ko‘rinadi.
- [ ] Tab, Enter/Space va Escape; dialog yopilgach fokus qaytadi.
- [ ] Tegishli storage reload’dan keyin to‘g‘ri; boshqa ma’lumot tozalanmagan.
- [ ] Ishlashga ta’sir qiladigan console error va resurs 404lari qolmagan.
- [ ] Kerakli source test/build o‘tdi; yangi build ko‘rsatilmoqda.
- [ ] Fake statistika/yuborish/to‘lov haqiqiy deb taqdim etilmagan.
- [ ] HANDOFF.md, run yo‘riqnomasi va qisqa himoya izohi yangilangan.

| Talab | Amal | Kod joyi | Tekshiruv | Natija / ochiq xato |
|---|---|---|---|---|
| Biletdan to‘ldiriladi | | | | Tekshirilmagan |
