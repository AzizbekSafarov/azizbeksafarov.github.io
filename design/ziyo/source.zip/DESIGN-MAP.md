# Ziyo — dizayn xaritasi

Foydalanuvchi kod yozmaydi va o‘zgarishni oddiy so‘z bilan aytadi. Bu fayl o‘sha so‘zni aniq fayl va amalga bog‘laydi. Qiymatlar shu paketdagi haqiqiy fayllardan olingan.

## Kimning so‘zi ustun

1. Foydalanuvchining aniq aytgani (rang, shrift, joylashuv, bo‘lim, matn) vizual kontraktdan ustun: darhol bajaring, “dizaynni saqlash kerak” deb rad etmang.
2. Bilet talabi va joydagi tashkilotchi ko‘rsatmasi hech qachon buzilmaydi; zid bo‘lsa, buni bir jumlada ayting va qaror so‘rang.
3. Aytilmagan hamma narsada shu dizaynning shrift, rang roli va tugma uslubi saqlanadi. Vizual kontrakt tasodifiy buzilishdan himoya qiladi, foydalanuvchini cheklamaydi.
4. O‘zgarishni butun saytga izchil qo‘llang: bitta tokenni o‘zgartirib, unga bog‘liq matn kontrasti (kamida 4.5:1), hover va tanlangan holatlarni ham tekshiring.

Build kerak emas: faylni saqlab, brauzerni yangilash yetarli.

## Foydalanuvchi aytsa

| So‘z | Qayerda | Nima qilinadi |
|---|---|---|
| “Rangni o‘zgartir”, “ko‘kroq qil” | “Asosiy ranglar” jadvali, `site/style.css` | Token yetmaydi: ko‘p rang to‘g‘ridan-to‘g‘ri yozilgan. Jadvaldagi qiymatni ko‘rsatilgan fayllarda birga almashtiring, keyin kontrastni tekshiring |
| “Shriftni almashtir”, “kattaroq yoz” | `site/style.css`, `@font-face` | Yangi shriftni loyihaga lokal qo‘shing; o‘lchamni sarlavha va matn darajalari bo‘yicha o‘zgartiring |
| “Matnni o‘zgartir”, “sarlavha boshqacha bo‘lsin” | `site/index.html`, `site/model.js` | Boshlang‘ich matn sahifada, takrorlanadigan kartalar ma’lumotda |
| “Rasmni almashtir” | `site/ (yangi `images/` papkasini oching)` | Faylni almashtiring, alt matnini yangilang, litsenziyani `CREDITS.md` ga yozing |
| “Yangi bo‘lim”, “yangi sahifa qo‘sh” | `site/index.html`, `site/app.js`, `site/layout.css` | Mavjud bo‘lim naqshidan foydalaning, navigatsiyaga ulang, responsive holatini qo‘shing |
| “Bu bo‘limni olib tashla” | `site/index.html`, `site/app.js` | Bo‘limni, unga havolani va ishlatilmay qolgan kodni birga olib tashlang |
| “Forma qo‘sh”, “tekshiruv bo‘lsin” | `site/model.js`, `site/app.js` | Qoidani modelga, xabarni ekranga yozing; bo‘sh va noto‘g‘ri qiymatni sinang |
| “Saqlansin”, “yangilaganda yo‘qolmasin” | `site/app.js` | Storage kaliti versiyasi bilan saqlang, reload va boshqa tabda sinang |
| “Telefonda buzilyapti” | `site/layout.css` | 390, 768 va 1366 px da ko‘ring, sababini tuzating |
| “Butunlay boshqa kayfiyat” | `site/style.css`, `site/layout.css` | Avval tokenlar va shriftlarni o‘zgartiring; freymvorkni almashtirmang |
| “Hakam shu joyni o‘zgartirishni so‘radi” | yuqoridagi qatorlar | Eng kichik xavfsiz tahrirni qiling, shu oqimni qayta sinang (`ZAXIRA/JONLI-OZGARISH.md`) |

## Fayllar

| Fayl | Qator | Vazifasi |
|---|---|---|
| `site/app.js` | 141 | tugmalar, dialoglar, saqlash va eksport |
| `site/identity.js` | 49 | dizaynga xos kichik holatlar |
| `site/index.html` | 86 | sahifa tuzilishi, bo‘limlar va boshlang‘ich matn |
| `site/layout.css` | 630 | sahifa joylashuvi, responsive va holatlar |
| `site/model.js` | 54 | namuna ma’lumotlar, tekshiruv va hisob-kitob |
| `site/style.css` | 277 | rang tokenlari, shriftlar va komponentlar |

## Rang tokenlari

| Token | Hozirgi qiymat |
|---|---|
| `--ink` | `#402d26` |
| `--line` | `#d8c9bb` |
| `--focus` | `#2451ad` |
| `--modal` | `#fffdf7` |

## Asosiy ranglar

Kodda eng ko‘p ishlatilgan to‘g‘ridan-to‘g‘ri qiymatlar. Rang o‘zgarishi saytda ko‘rinishi uchun shu qiymatlarni almashtiring.

| Rang | Marta | Fayllar |
|---|---|---|
| `#ffffff` | 5 | layout.css, style.css |
| `#402d26` | 4 | layout.css |
| `#bd4731` | 4 | layout.css |
| `#2451ad` | 3 | layout.css |
| `#ffedd6` | 2 | index.html, layout.css |
| `#fffaf2` | 2 | layout.css |
| `#fffdf8` | 2 | layout.css |
| `#f3f0e8` | 2 | layout.css |
| `#772c3c` | 2 | layout.css |
| `#fff6e9` | 2 | layout.css |
| `#111111` | 2 | style.css |
| `#d8c9bb` | 1 | layout.css |
| `#fffdf7` | 1 | layout.css |
| `#ddcbb7` | 1 | layout.css |

## Shriftlar

- Study Display — `fonts/breeserif.ttf`
- Study Sans — `fonts/nunitosans.ttf`
- Study Mono — `fonts/mono.ttf`

## Sahifa bo‘limlari

| Teg | id | Tavsif |
|---|---|---|
| `main` | `main` |  |
| `aside` | `practice` | Dars mashqi |
| `nav` | `—` | Qo‘shimcha havolalar |
