const $ = s => document.querySelector(s);
let mode = 'structure',
  clicks = 0,
  painted = false;
const states = {
  structure: ['HTML · SAHIFA TUZILISHI', 'Mening birinchi loyiham', 'Teglar mazmunga vazifa beradi.'],
  style: ['CSS · VIZUAL IYERARXIYA', 'Muhim fikr ko‘zga tashlanadi.', 'O‘lcham va rang diqqatni boshqaradi.'],
  interaction: [
    'JAVASCRIPT · AMAL VA NATIJA',
    'Bosishdan keyin nima bo‘ladi?',
    'Tugmani bosing va natijani kuzating.'
  ]
};
export function showLesson(p) {
  mode = p.id;
  clicks = 0;
  const s = states[mode];
  $('#demo-webpage').dataset.mode = mode;
  $('#demo-label').textContent = s[0];
  $('#demo-title').textContent = s[1];
  $('#demo-result').textContent = s[2];
  $('#demo-action').textContent = mode === 'interaction' ? 'Hisobni oshirish +' : 'Sinab ko‘rish';
  if (painted && !matchMedia('(prefers-reduced-motion: reduce)').matches)
    $('#demo-webpage').animate(
      [
        { opacity: 0, transform: 'translateY(8px) rotate(-1deg)' },
        { opacity: 1, transform: 'none' }
      ],
      { duration: 350, easing: 'ease-out' }
    );
  painted = true;
}
$('#demo-action').addEventListener('click', () => {
  clicks++;
  $('#demo-result').textContent =
    mode === 'interaction'
      ? 'Natija: ' + clicks + ' marta bosildi.'
      : mode === 'style'
        ? 'Tugmaning kontrasti va o‘lchami amalni ajratib turibdi.'
        : 'HTML button elementi sichqoncha va klaviaturada ishlaydi.';
  if (!matchMedia('(prefers-reduced-motion: reduce)').matches)
    $('#demo-result').animate(
      [
        { opacity: 0, transform: 'translateY(4px)' },
        { opacity: 1, transform: 'none' }
      ],
      { duration: 220 }
    );
});
