# Nashr

No npm install. `python -m http.server 8080 --bind 127.0.0.1` here, or ZIP root `node serve.mjs`. `node --test model.test.mjs`.

Edit index.html, style.css, app.js, model.js. Keep IDs aligned. Newsreader reading serif + DM Sans yordamchi yozuv. Qog‘oz fon, qora siyoh, qizil tahririy belgi. Masthead va zich asimmetrik gazeta ustunlari. Landing-page hero emas.

Flow: Bo‘lim filtri → maqola o‘qish → saqlash → saqlanganlar → qayta ochish.

Original library generator: design/build_collection.py. In isolated competition copy edit runtime files directly. Read CREDITS.md. No backend, orders, accounts or tracking.


At ZIP root run node serve.mjs. Editable files are site/. Read AGENTS.md and AI-BRIEF.md.
