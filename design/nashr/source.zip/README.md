# Nashr — portable competition starter

## Boshlash

AI uchun ish qoidalari va o‘qish tartibi: `AGENTS.md`. Bilet loyiha davomida `CURRENT-TASK.md` ga yoziladi. Kod `site/` papkasida.

## Oldindan yig‘ilgan nusxa, npm o‘rnatmasdan

```text
node serve.mjs
```

Eng osoni: `ochish.cmd` ni ikki marta bosing. Node bo‘lmasa u Windows PowerShell bilan ochadi. `index.html` ni to‘g‘ridan-to‘g‘ri ochmang: brauzer skript va shriftlarni bloklaydi.

Brauzer: http://127.0.0.1:8080/ . Server faqat 127.0.0.1’da ishlaydi. Port band bo‘lsa PowerShell’da `$env:PORT=8081; node serve.mjs`. Ctrl+C bilan to‘xtatiladi.

Node bo‘lmasa Python:

```text
python -m http.server 8080 --bind 127.0.0.1 --directory site
```

Python preview manzili: http://127.0.0.1:8080/index.html

## Tahrirlash

ZIP ildiziga nisbatan: `site/index.html` — sahifa; `site/app.js` — amallar; `site/model.js` — ma’lumot va mantiq; `site/style.css` — uslub. Qo‘shimcha fayllar AI-BRIEF.md da. Test: `node --test site/*.test.mjs`. Npm va build shart emas. ES modullar uchun HTTP preview ishlating, file:// emas. Boshqa starterlar bu site/ papkasida yo‘q.

## Boshqa kompyuterda davom ettirish

Butun paketni yangi bo‘sh papkaga oching. Avval `node verify-package.mjs`, keyin tahrir: bu asl nusxa tekshiruvi, tahrirlangan loyihada hash farqi tabiiy. CURRENT-TASK.md va HANDOFF.md to‘ldirilgan bo‘lsa ularni ochiq saytdagi bo‘sh shablon bilan almashtirmang. Brauzerdagi localStorage ZIP bilan ko‘chmaydi; kerakli demo holatini eksport/import yoki qayta kiritish orqali tayyorlang. Maxfiy kalitlar topshiriladigan kodga kiritilmaydi.


CHECKLIST.md bilan sinang. HANDOFF.md ga haqiqiy natijalarni yozing. Namuna statistika, profil, narxlar, formalar va datasetlar haqiqiy xizmat emas. Tashqi CDN runtime’da kerak emas; fonts/licenses ZIP ichida. To‘liq tanlov tadqiqoti barcha dizaynlar paketi `kit.zip` ichida va https://azizbeksafarov.github.io/ustoz/ai.md da.

Paket tarkibi: START-HERE.md. Codex bilan ishlash: ZAXIRA/CODEX.md. AI ishlamasa, AI’siz yo‘l: ZAXIRA/ZAXIRA.md.
