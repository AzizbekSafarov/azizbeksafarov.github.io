# HANDOFF — Nashr

## Snapshot
- Manba: https://azizbeksafarov.github.io/design/nashr/
- Paket sanasi: 2026-10-31; source fingerprint: 9d2719046bd7971f9826848a55d09b451d7403a554ae31a9fe10d09739aed27e
- Holat: oldindan tayyorlangan demo. Hozirgi biletga moslashtirish hali bajarilmagan.
- Baseline QA: ZIP ichidagi site/QA-REPORT.md; Kengaytirilgan tekshiruv: /design/QA-EXPANDED.md. Har bir paket o‘z model va kombinatsiya testlarini olib yuradi; markaziy event-fixture sinovlari faqat to‘liq repoda. Bu yangi o‘zgarishlar uchun avtomatik dalil emas.

## Hozirgi topshiriq
- Bilet: CURRENT-TASK.md ga yoziladi.
- Qolgan vaqt va ishdagi local URL: hali kiritilmagan.
- Bajarilgan talablar: hali kiritilmagan.
- O‘zgargan fayllar: hali kiritilmagan.
- O‘tkazilgan testlar va natija: hali kiritilmagan.
- Ochiq xato / cheklov: demo browser-local; haqiqiy backend/yuborish yo‘q.
- Keyingi amal: biletni talab → amal → qabul sinovi jadvaliga ajratish.

## Keyingi AIga topshirish
Keyingi AI: `AGENTS.md` dagi tartib bilan o‘qiydi — bilet, shu fayl, `AI-BRIEF.md`, tanlov qoidalari, so‘ng tegishli source. Tekshirilmagan bandni bajarilgan deb belgilama; har katta bosqichdan keyin shu faylni yangila.
