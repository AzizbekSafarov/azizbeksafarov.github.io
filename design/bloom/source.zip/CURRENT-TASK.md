# Hozirgi tanlov topshirig‘i

- Biletning aynan matni: hali berilmagan.
- Foydalanuvchi va maqsad: biletdan olinadi.
- Majburiy funksiyalar: biletdan olinadi.
- Amaliy ish uchun haqiqiy qolgan vaqt: hali kiritilmagan.
- Joydagi vosita/internet/shablon talablari: tasdiqlanganini yozing.
- Tanlangan dizayn: Bloom · Material Design 3

## Arxitektura va haqiqiy holat
Render + Supabase tayyorgarlik rejasi: ARCHITECTURE.md. Haqiqiy yaratilgan xizmat va URLlarni shu yerga yozing; PROJECT-STATUS.json — ommaviy snapshot, jonli holat emas. To‘liq maydonlar uchun PROJECT-TASK-TEMPLATE.md dan foydalanish mumkin.
