# Bloom · Material Design 3 — portable competition starter

## Boshlash

AI uchun: AGENTS.md → AI-BRIEF.md → CURRENT-TASK.md → HANDOFF.md. Bilet hali bu paketga yozilmagan. Kod `site/` papkasida. Internet/shablon ruxsati tanlovdagi amaldagi tartibga bog‘liq.

## Oldindan yig‘ilgan nusxa, npm o‘rnatmasdan

```text
node serve.mjs
```

Brauzer: http://127.0.0.1:8080/ . Server faqat 127.0.0.1’da ishlaydi. Port band bo‘lsa PowerShell’da `$env:PORT=8081; node serve.mjs`. Ctrl+C bilan to‘xtatiladi.

Node bo‘lmasa Python:

```text
python -m http.server 8080 --bind 127.0.0.1 --directory site/dist
```

Python preview manzili: http://127.0.0.1:8080/index.html

## Tahrirlash

Bloom uchun `site/src/` ni tahrirlang. `cd site`, `npm ci`, `npm run test`, `npm run build`. Development: `npm run dev`. Paketda node_modules yo‘q; source build uchun Node.js 20.19+ yoki 22.12+, npm va o‘rnatilgan/cache’dagi paketlar yoki internet kerak. `dist/` esa hozirdan tayyor. Minified buildni qo‘lda tahrirlamang.

CHECKLIST.md bilan sinang. HANDOFF.md ga haqiqiy natijalarni yozing. Namuna statistika, profil, narxlar, formalar va datasetlar haqiqiy xizmat emas. Tashqi CDN runtime’da kerak emas; fonts/licenses ZIP ichida. To‘liq tanlov tadqiqoti barcha dizaynlar paketi `kit.zip` ichida va https://azizbeksafarov.github.io/ustoz/ai.md da.


## Joriy kontekst
WORKFLOW.md → PROJECT-STATUS.json → ARCHITECTURE.md → API-GUIDE.md. Ehtimoliy xavflar aniqlangan xato emas. Haqiqiy loyiha holati CURRENT-TASK.md va HANDOFF.md’da saqlanadi. Bu hujjatlar backendni avtomatik yaratmaydi.

To‘liq o‘qish: START-HERE.md → PREPARATION.md → READING-PLAN.json. Qisqa brif to‘liq hujjatni almashtirmaydi.
