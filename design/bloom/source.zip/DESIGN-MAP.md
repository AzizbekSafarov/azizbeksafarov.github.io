# Bloom · Material Design 3 — dizayn xaritasi

Foydalanuvchi kod yozmaydi va o‘zgarishni oddiy so‘z bilan aytadi. Bu fayl o‘sha so‘zni aniq fayl va amalga bog‘laydi. Qiymatlar shu paketdagi haqiqiy fayllardan olingan.

## Kimning so‘zi ustun

1. Foydalanuvchining aniq aytgani (rang, shrift, joylashuv, bo‘lim, matn) vizual kontraktdan ustun: darhol bajaring, “dizaynni saqlash kerak” deb rad etmang.
2. Bilet talabi va joydagi tashkilotchi ko‘rsatmasi hech qachon buzilmaydi; zid bo‘lsa, buni bir jumlada ayting va qaror so‘rang.
3. Aytilmagan hamma narsada shu dizaynning shrift, rang roli va tugma uslubi saqlanadi. Vizual kontrakt tasodifiy buzilishdan himoya qiladi, foydalanuvchini cheklamaydi.
4. O‘zgarishni butun saytga izchil qo‘llang: bitta tokenni o‘zgartirib, unga bog‘liq matn kontrasti (kamida 4.5:1), hover va tanlangan holatlarni ham tekshiring.

Har tahrirdan keyin `site/` ichida `npm run test` va `npm run build` bajaring; ko‘rinadigan natija `site/dist/` dan chiqadi.

## Foydalanuvchi aytsa

| So‘z | Qayerda | Nima qilinadi |
|---|---|---|
| “Rangni o‘zgartir”, “ko‘kroq qil” | “Asosiy ranglar” jadvali, `site/src/style.css` | Token yetmaydi: ko‘p rang to‘g‘ridan-to‘g‘ri yozilgan. Jadvaldagi qiymatni ko‘rsatilgan fayllarda birga almashtiring, keyin kontrastni tekshiring |
| “Shriftni almashtir”, “kattaroq yoz” | `site/src/style.css`, `@font-face` | Yangi shriftni loyihaga lokal qo‘shing; o‘lchamni sarlavha va matn darajalari bo‘yicha o‘zgartiring |
| “Matnni o‘zgartir”, “sarlavha boshqacha bo‘lsin” | `site/src/main.jsx`, `site/src/model.js` | Boshlang‘ich matn sahifada, takrorlanadigan kartalar ma’lumotda |
| “Rasmni almashtir” | `site/public/` | Faylni almashtiring, alt matnini yangilang, litsenziyani `CREDITS.md` ga yozing |
| “Yangi bo‘lim”, “yangi sahifa qo‘sh” | `site/src/main.jsx`, `site/src/main.jsx`, `site/src/style.css` | Mavjud bo‘lim naqshidan foydalaning, navigatsiyaga ulang, responsive holatini qo‘shing |
| “Bu bo‘limni olib tashla” | `site/src/main.jsx`, `site/src/main.jsx` | Bo‘limni, unga havolani va ishlatilmay qolgan kodni birga olib tashlang |
| “Forma qo‘sh”, “tekshiruv bo‘lsin” | `site/src/model.js`, `site/src/main.jsx` | Qoidani modelga, xabarni ekranga yozing; bo‘sh va noto‘g‘ri qiymatni sinang |
| “Saqlansin”, “yangilaganda yo‘qolmasin” | `site/src/main.jsx` | Storage kaliti versiyasi bilan saqlang, reload va boshqa tabda sinang |
| “Telefonda buzilyapti” | `site/src/style.css` | 390, 768 va 1366 px da ko‘ring, sababini tuzating |
| “Butunlay boshqa kayfiyat” | `site/src/style.css`, `site/src/style.css` | Avval tokenlar va shriftlarni o‘zgartiring; freymvorkni almashtirmang |
| “Hakam shu joyni o‘zgartirishni so‘radi” | yuqoridagi qatorlar | Eng kichik xavfsiz tahrirni qiling, shu oqimni qayta sinang (`ZAXIRA/JONLI-OZGARISH.md`) |

## Fayllar

| Fayl | Qator | Vazifasi |
|---|---|---|
| `site/index.html` | — | Vite kirish fayli |
| `site/src/main.jsx` | 1061 | ekranlar, tugmalar va Material komponentlari |
| `site/src/model.js` | 167 | namuna ma’lumotlar, tekshiruv va hisob-kitob |
| `site/src/persistence.js` | 53 | brauzerda saqlash |
| `site/src/ProjectWorkspace.jsx` | 216 | loyiha ichidagi ish maydoni |
| `site/src/routes.js` | 13 | hash manzillar |
| `site/src/style.css` | 2061 | rang tokenlari, shriftlar va komponentlar |
| `site/src/workspace.css` | 284 | loyiha ish maydoni uslubi |

## Rang tokenlari

| Token | Hozirgi qiymat |
|---|---|
| `--md-sys-color-primary` | `#6750a4` |
| `--md-sys-color-on-primary` | `#fff` |
| `--md-sys-color-primary-container` | `#eaddff` |
| `--md-sys-color-on-primary-container` | `#21005d` |
| `--md-sys-color-secondary` | `#625b71` |
| `--md-sys-color-secondary-container` | `#e8def8` |
| `--md-sys-color-on-secondary-container` | `#1d192b` |
| `--md-sys-color-tertiary` | `#7d5260` |
| `--md-sys-color-tertiary-container` | `#ffd8e4` |
| `--md-sys-color-on-tertiary-container` | `#31111d` |
| `--md-sys-color-surface` | `#fdf7ff` |
| `--md-sys-color-surface-container-lowest` | `#fff` |
| `--md-sys-color-surface-container-low` | `#f7f2fa` |
| `--md-sys-color-surface-container` | `#f3edf7` |
| `--md-sys-color-surface-container-high` | `#ece6f0` |
| `--md-sys-color-surface-container-highest` | `#e6e0e9` |
| `--md-sys-color-on-surface` | `#1d1b20` |
| `--md-sys-color-on-surface-variant` | `#49454f` |
| `--md-sys-color-outline` | `#79747e` |
| `--md-sys-color-outline-variant` | `#cac4d0` |
| `--md-sys-color-error` | `#b3261e` |
| `--md-sys-color-error-container` | `#f9dedc` |
| `--md-sys-color-on-error-container` | `#410e0b` |
| `--md-sys-color-inverse-surface` | `#322f35` |
| `--md-sys-color-inverse-on-surface` | `#f5eff7` |

## Asosiy ranglar

Kodda eng ko‘p ishlatilgan to‘g‘ridan-to‘g‘ri qiymatlar. Rang o‘zgarishi saytda ko‘rinishi uchun shu qiymatlarni almashtiring.

| Rang | Marta | Fayllar |
|---|---|---|
| `#6750a4` | 2 | main.jsx, style.css |
| `#ffffff` | 2 | style.css |
| `#1a73e8` | 1 | main.jsx |
| `#00856a` | 1 | main.jsx |
| `#ad4d25` | 1 | main.jsx |
| `#eaddff` | 1 | style.css |
| `#21005d` | 1 | style.css |
| `#625b71` | 1 | style.css |
| `#e8def8` | 1 | style.css |
| `#1d192b` | 1 | style.css |
| `#7d5260` | 1 | style.css |
| `#ffd8e4` | 1 | style.css |
| `#31111d` | 1 | style.css |
| `#fdf7ff` | 1 | style.css |

## Shriftlar

- Google Sans Flex — `google-sans-flex-latin-ext.woff2`
- Google Sans Flex — `google-sans-flex-latin.woff2`
- Material Symbols Rounded — `./material-symbols.woff2`
- Roboto — `./roboto-400.ttf`
- Roboto — `./roboto-500.ttf`
- Roboto — `./roboto-600.ttf`
