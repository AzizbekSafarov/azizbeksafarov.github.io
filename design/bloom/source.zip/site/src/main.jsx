import React, { useState, useEffect, useRef, useCallback } from 'react';
import { createRoot } from 'react-dom/client';
import { motion, AnimatePresence, MotionConfig, useReducedMotion } from 'motion/react';
import '@material/web/button/filled-button.js';
import '@material/web/button/filled-tonal-button.js';
import '@material/web/button/outlined-button.js';
import '@material/web/button/text-button.js';
import '@material/web/iconbutton/icon-button.js';
import '@material/web/fab/fab.js';
import '@material/web/chips/filter-chip.js';
import '@material/web/chips/chip-set.js';
import '@material/web/select/outlined-select.js';
import '@material/web/select/select-option.js';
import '@material/web/textfield/outlined-text-field.js';
import '@material/web/checkbox/checkbox.js';
import '@material/web/radio/radio.js';
import '@material/web/progress/linear-progress.js';
import '@material/web/dialog/dialog.js';
import '@material/web/ripple/ripple.js';
import {
  argbFromHex,
  hexFromArgb,
  Hct,
  SchemeTonalSpot,
  MaterialDynamicColors
} from '@material/material-color-utilities';
import { categories, visibleProjects, createProject, progress } from './model.js';
import { loadProjectState, persistProjectState, exportProjects } from './persistence.js';
import { readRoute, routeHash } from './routes.js';
import { ProjectWorkspace } from './ProjectWorkspace.jsx';
import './style.css';
import './workspace.css';
const SPRING = { type: 'spring', stiffness: 380, damping: 29, mass: 1 };
function Icon({ name, size = 24, fill, style, ...props }) {
  return (
    <span
      {...props}
      aria-hidden="true"
      className="material-symbols"
      style={{ fontSize: size, fontVariationSettings: `'FILL' ${fill && fill !== 'none' ? 1 : 0}`, ...style }}
    >
      {name}
    </span>
  );
}
function DownloadIcon({ size = 18, ...props }) {
  return (
    <svg
      {...props}
      aria-hidden="true"
      focusable="false"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12 3v12m-5-5 5 5 5-5M5 17v4h14v-4" />
    </svg>
  );
}
const Plus = p => <Icon name="add" {...p} />,
  Search = p => <Icon name="search" {...p} />,
  X = p => <Icon name="close" {...p} />,
  ArrowUpRight = p => <Icon name="arrow_outward" {...p} />,
  ArrowRight = p => <Icon name="arrow_forward" {...p} />,
  Bookmark = p => <Icon name="bookmark" {...p} />,
  LayoutGrid = p => <Icon name="grid_view" {...p} />,
  Check = p => <Icon name="check" {...p} />,
  CheckCheck = p => <Icon name="check_circle" {...p} />,
  Sun = p => <Icon name="light_mode" {...p} />,
  Moon = p => <Icon name="dark_mode" {...p} />,
  ChevronDown = p => <Icon name="expand_more" {...p} />,
  HelpCircle = p => <Icon name="help" {...p} />,
  Leaf = p => <Icon name="check_circle" {...p} />,
  FolderOpen = p => <Icon name="folder_open" {...p} />,
  ExternalLink = p => <Icon name="arrow_outward" {...p} />,
  Home = p => <Icon name="home" {...p} />,
  Star = p => <Icon name="star" {...p} />,
  List = p => <Icon name="list" {...p} />,
  HardDrive = p => <Icon name="storage" {...p} />,
  Cloud = p => <Icon name="cloud" {...p} />,
  ChevronRight = p => <Icon name="chevron_right" {...p} />,
  GraduationCap = p => <Icon name="school" {...p} />,
  Palette = p => <Icon name="palette" {...p} />,
  Code2 = p => <Icon name="code" {...p} />;
function ProjectIcon({ category, size = 24 }) {
  const Element = category === 'Ta’lim' ? GraduationCap : category === 'Dizayn' ? Palette : Code2;
  return <Element size={size} />;
}
function Art({ kind = 'flower', title = 'Yangi loyiha', category = 'Loyiha' }) {
  return (
    <div className={`material-cover cover-${kind}`} aria-hidden="true">
      <div className="cover-ring" />
      <div className="cover-page">
        <span className="cover-kicker">{category}</span>
        <strong>{title}</strong>
        <div className="cover-sample">
          <span />
          <span />
          <span />
        </div>
        <div className="cover-caption">G‘oya · Reja · Natija</div>
      </div>
    </div>
  );
}
function BloomMark() {
  return (
    <svg aria-hidden="true" viewBox="0 0 40 40">
      <rect x="3" y="3" width="34" height="34" rx="12" fill="currentColor" />
      <path
        d="M12 27V13h8a5 5 0 0 1 0 10h-8m0-5h10a4.5 4.5 0 0 1 0 9H12"
        fill="none"
        stroke="var(--md-sys-color-on-primary)"
        strokeWidth="2.4"
        strokeLinejoin="round"
      />
    </svg>
  );
}
function Button({ children, className = '', type = 'button', ...props }) {
  if (className === 'preview-open')
    return (
      <button {...props} type={type} className={className}>
        <md-ripple />
        {children}
      </button>
    );
  if (className.includes('filter'))
    return (
      <md-filter-chip
        {...props}
        className={className}
        selected={props['aria-pressed']}
        label={React.Children.toArray(children)
          .filter(c => typeof c === 'string')
          .join('')
          .trim()}
      />
    );
  const Tag = className.includes('new-button')
    ? 'md-fab'
    : className.includes('icon-button')
      ? 'md-icon-button'
      : className.includes('filled')
        ? 'md-filled-button'
        : className.includes('tonal') || className.includes('chosen')
          ? 'md-filled-tonal-button'
          : className.includes('outlined')
            ? 'md-outlined-button'
            : 'md-text-button';
  const items = React.Children.toArray(children).map(child =>
    React.isValidElement(child) && child.props.size
      ? React.cloneElement(child, { slot: Tag === 'md-icon-button' ? undefined : 'icon' })
      : child
  );
  return (
    <Tag {...props} type={type} className={className}>
      {items}
    </Tag>
  );
}
function Modal({ open, onOpenChange, title, description, children, actions, opener, className = '' }) {
  const dialog = useRef(null);
  const reduce = useReducedMotion();
  useEffect(() => {
    const el = dialog.current;
    const closed = () => {
      onOpenChange(false);
      const target = opener?.current?.isConnected
        ? opener.current
        : document.getElementById('projects-heading');
      target?.focus({ preventScroll: true });
    };
    el.addEventListener('closed', closed);
    return () => el.removeEventListener('closed', closed);
  }, [onOpenChange, opener]);
  useEffect(() => {
    const el = dialog.current;
    if (open) el.show();
    else if (el.open) el.close();
  }, [open]);
  return (
    <md-dialog ref={dialog} quick={reduce} className={`material-dialog ${className}`} aria-label={title}>
      <div slot="headline" className="dialog-heading" aria-label={title}>
        <span>{title}</span>
        <Button className="icon-button" aria-label="Oynani yopish" onClick={() => onOpenChange(false)}>
          <X size={24} />
        </Button>
      </div>
      <div slot="content">
        <p className="dialog-description">{description}</p>
        {children}
      </div>
      {actions && <div slot="actions">{actions}</div>}
    </md-dialog>
  );
}
const SEEDS = [
  { color: '#6750a4', label: 'Binafsha' },
  { color: '#1a73e8', label: 'Ko‘k' },
  { color: '#00856a', label: 'Yashil' },
  { color: '#ad4d25', label: 'Terrakota' }
];
function applyMaterialTheme(seed, dark) {
  const scheme = new SchemeTonalSpot(Hct.fromInt(argbFromHex(seed)), dark, 0);
  const roles = new MaterialDynamicColors();
  for (const color of roles.allColors) {
    document.documentElement.style.setProperty(
      '--md-sys-color-' + color.name.replaceAll('_', '-'),
      hexFromArgb(color.getArgb(scheme))
    );
  }
}
function App() {
  const [route, setRoute] = useState(() => readRoute(location.hash));
  const dirtyEditor = useRef(false),
    currentHash = useRef(location.hash),
    lastProject = useRef(null);
  const markDirty = useCallback(value => {
    dirtyEditor.current = value;
  }, []);
  useEffect(() => {
    function changed() {
      if (location.hash === '#main') return;
      if (dirtyEditor.current && !window.confirm('Saqlanmagan tahrir bor. Bu ekrandan chiqilsinmi?')) {
        history.replaceState(null, '', currentHash.current || location.pathname + location.search);
        return;
      }
      dirtyEditor.current = false;
      currentHash.current = location.hash;
      const next = readRoute(location.hash);
      setRoute(next);
      setView(next.view);
    }
    window.addEventListener('hashchange', changed);
    return () => window.removeEventListener('hashchange', changed);
  }, []);
  useEffect(() => {
    const frame = requestAnimationFrame(() => {
      if (route.projectId || route.invalid) {
        document.getElementById('project-heading')?.focus({ preventScroll: true });
        window.scrollTo({ top: 0, behavior: 'instant' });
      } else if (lastProject.current) {
        const el = [...document.querySelectorAll('[data-project-id]')].find(
          e => e.dataset.projectId === lastProject.current
        );
        (el || document.getElementById('projects-heading'))?.focus({ preventScroll: true });
      }
      if (route.projectId) lastProject.current = route.projectId;
    });
    return () => cancelAnimationFrame(frame);
  }, [route]);

  const reduce = useReducedMotion();
  const [startup] = useState(() => loadProjectState(() => localStorage));
  const [projects, setProjects] = useState(startup.projects);
  const [view, setView] = useState(route.view);
  const [category, setCategory] = useState('Hammasi');
  const [query, setQuery] = useState('');
  const [sort, setSort] = useState('recent');
  const selected = route.projectId;
  const [createOpen, setCreateOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const [theme, setTheme] = useState(() => {
    try {
      return localStorage.getItem('ustoz.bloom.theme') === 'dark' ? 'dark' : 'light';
    } catch {
      return 'light';
    }
  });
  const [toast, setToast] = useState('');
  const [storageStatus, setStorageStatus] = useState(startup.status);
  const [formError, setFormError] = useState('');
  const [formVersion, setFormVersion] = useState(0);
  const [display, setDisplay] = useState('grid');
  const [paletteOpen, setPaletteOpen] = useState(false);
  const paletteOpener = useRef(null);
  const [seed, setSeed] = useState(() => {
    try {
      const stored = localStorage.getItem('ustoz.bloom.seed');
      return SEEDS.some(s => s.color === stored) ? stored : SEEDS[0].color;
    } catch {
      return SEEDS[0].color;
    }
  });
  const createOpener = useRef(null);
  const helpOpener = useRef(null);
  const searchRef = useRef(null);
  const headingRef = useRef(null);
  const lastStored = useRef(startup.raw);
  useEffect(() => {
    if (projects === startup.projects) return;
    const result = persistProjectState(() => localStorage, projects, {
      startupStatus: startup.status,
      expectedRaw: lastStored.current
    });
    if (result.raw !== undefined) lastStored.current = result.raw;
    setStorageStatus(result.status);
    if (result.status === 'conflict')
      setToast('Boshqa tabdagi nusxa saqlandi. Bu tabdagi ishni faylga yuklab oling.');
    else if (['unavailable', 'invalid-current'].includes(result.status))
      setToast('Brauzerga saqlanmadi. Ish shu tabda; nusxani faylga yuklab oling.');
  }, [projects, startup]);
  useEffect(() => {
    try {
      localStorage.setItem('ustoz.bloom.theme', theme);
    } catch {}
    document.documentElement.dataset.theme = theme;
    applyMaterialTheme(seed, theme === 'dark');
    try {
      localStorage.setItem('ustoz.bloom.seed', seed);
    } catch {}
  }, [theme, seed]);
  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(''), 3200);
    return () => clearTimeout(timer);
  }, [toast]);
  useEffect(() => {
    function shortcut(event) {
      if (
        event.key === '/' &&
        !event.ctrlKey &&
        !event.metaKey &&
        !document.querySelector('md-dialog[open]') &&
        !['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName) &&
        !document.activeElement?.isContentEditable &&
        !document.activeElement?.tagName?.startsWith('MD-')
      ) {
        event.preventDefault();
        searchRef.current?.focus();
      }
    }
    window.addEventListener('keydown', shortcut);
    return () => window.removeEventListener('keydown', shortcut);
  }, []);
  const filtered = visibleProjects(projects, { view, category, query, sort });
  const done = projects.filter(p => progress(p) === 1).length;
  const saved = projects.filter(p => p.saved).length;
  const totalTasks = projects.reduce((n, p) => n + p.tasks.length, 0);
  const checkedTasks = projects.reduce((n, p) => n + p.tasks.filter(t => t.done).length, 0);
  const selectedProject = projects.find(p => p.id === selected);
  const totalPercent = totalTasks ? Math.round((checkedTasks / totalTasks) * 100) : 0;
  function downloadBackup() {
    const url = URL.createObjectURL(
      new Blob([exportProjects(projects)], { type: 'application/json;charset=utf-8' })
    );
    const link = document.createElement('a');
    link.href = url;
    link.download = 'bloom-loyihalar.json';
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    setToast('Loyihalar nusxasi yuklashga topshirildi');
  }
  function navigate(next) {
    location.hash = routeHash(next);
    if (!route.projectId && !route.invalid) {
      setView(next);
      setCategory('Hammasi');
      setQuery('');
    }
  }
  function openProject(event, id) {
    location.hash = routeHash(view, id);
  }
  function startProject(event) {
    createOpener.current = event.currentTarget;
    setFormError('');
    setCreateOpen(true);
  }
  function toggleSaved(id) {
    setProjects(prev => prev.map(p => (p.id === id ? { ...p, saved: !p.saved } : p)));
    const project = projects.find(p => p.id === id);
    setToast(project.saved ? 'Saqlanganlar belgisi olib tashlandi' : 'Saqlanganlar belgisi qo‘yildi');
    if (view === 'saved' && project.saved && !route.projectId)
      requestAnimationFrame(() => headingRef.current?.focus({ preventScroll: true }));
  }
  function updateProject(next) {
    setProjects(prev => prev.map(p => (p.id === next.id ? next : p)));
  }
  function changeTask(id, index) {
    setProjects(prev =>
      prev.map(p =>
        p.id === id ? { ...p, tasks: p.tasks.map((t, i) => (i === index ? { ...t, done: !t.done } : t)) } : p
      )
    );
  }
  function submitProject(event) {
    event.preventDefault();
    try {
      const project = createProject(
        {
          title: String(event.currentTarget.querySelector('[name=title]').value || ''),
          description: String(event.currentTarget.querySelector('[name=description]').value || ''),
          category: String(event.currentTarget.querySelector('[name=category]').value || '')
        },
        crypto.randomUUID()
      );
      if (projects.length >= 200) {
        setFormError('Bu demo 200 tagacha loyiha saqlaydi.');
        return;
      }
      setProjects(prev => [project, ...prev]);
      navigate('all');
      setSort('recent');
      setCreateOpen(false);
      setToast('Yangi loyiha yaratildi');
      setFormVersion(v => v + 1);
    } catch {
      setFormError('Loyiha nomini yozing va yo‘nalishini tanlang.');
      event.currentTarget.querySelector('[name=title]')?.focus();
    }
  }
  const transition = reduce ? { duration: 0 } : SPRING;
  return (
    <MotionConfig reducedMotion="user" transition={transition}>
      <a
        className="skip-link"
        href="#main"
        onClick={event => {
          event.preventDefault();
          const main = document.getElementById('main');
          main?.focus({ preventScroll: true });
          main?.scrollIntoView({ behavior: 'instant' });
        }}
      >
        Asosiy mazmunga o‘tish
      </a>
      <div className="app-shell">
        <aside className="sidebar">
          <a href="#all" className="rail-brand" aria-label="Bloom bosh sahifasi">
            <BloomMark />
          </a>
          <Button className="new-button" onClick={startProject} aria-label="Yangi loyiha yaratish">
            <Plus size={24} />
          </Button>
          <nav aria-label="Asosiy navigatsiya">
            {[
              { id: 'all', icon: Home, label: 'Loyihalar' },
              { id: 'saved', icon: Bookmark, label: 'Saqlangan' },
              { id: 'done', icon: CheckCheck, label: 'Bajarilgan' }
            ].map(item => (
              <button
                id={`nav-${item.id}`}
                key={item.id}
                className={`nav-item ${view === item.id ? 'active' : ''}`}
                onClick={() => {
                  navigate(item.id);
                  headingRef.current?.scrollIntoView({
                    behavior: reduce ? 'instant' : 'smooth',
                    block: 'start'
                  });
                }}
                aria-current={view === item.id ? 'page' : undefined}
              >
                <span className="nav-icon">
                  {view === item.id && (
                    <motion.span className="nav-selection" layoutId="nav-selection" transition={transition} />
                  )}
                  <md-ripple for={`nav-${item.id}`} />
                  <item.icon size={24} fill={view === item.id ? 'currentColor' : 'none'} />
                </span>
                <span>{item.label}</span>
              </button>
            ))}
          </nav>
          <Button
            className="icon-button rail-help"
            aria-label="Bloom haqida"
            onClick={event => {
              helpOpener.current = event.currentTarget;
              setHelpOpen(true);
            }}
          >
            <HelpCircle size={24} />
          </Button>
        </aside>
        <main id="main" className="workspace" tabIndex={-1}>
          <header className="topbar">
            <a href="#all" className="wordmark">
              Bloom<span>Ijod maydoni</span>
            </a>
            <div className="search" hidden={!!route.projectId || route.invalid}>
              <Search size={24} />
              <input
                ref={searchRef}
                value={query}
                onChange={e => setQuery(e.target.value)}
                type="search"
                aria-label="Loyihalarni qidirish"
                placeholder="Loyihalarni qidirish"
                onKeyDown={e => {
                  if (e.key === 'Escape') setQuery('');
                  if (e.key === 'Enter') headingRef.current?.focus({ preventScroll: true });
                }}
              />
              {query ? (
                <Button
                  className="icon-button"
                  onClick={() => {
                    setQuery('');
                    searchRef.current?.focus();
                  }}
                  aria-label="Qidiruvni tozalash"
                >
                  <X size={24} />
                </Button>
              ) : (
                <kbd>/</kbd>
              )}
            </div>
            <div className="top-actions">
              <Button
                className="icon-button top-help"
                aria-label="Bloom haqida"
                onClick={event => {
                  helpOpener.current = event.currentTarget;
                  setHelpOpen(true);
                }}
              >
                <HelpCircle size={24} />
              </Button>
              <Button
                className="icon-button"
                aria-label="Rang palitrasini tanlash"
                onClick={event => {
                  paletteOpener.current = event.currentTarget;
                  setPaletteOpen(true);
                }}
              >
                <Palette size={24} />
              </Button>
              <Button
                className="icon-button"
                aria-label={theme === 'light' ? 'Qorong‘i rejimga o‘tish' : 'Yorug‘ rejimga o‘tish'}
                onClick={() => setTheme(t => (t === 'light' ? 'dark' : 'light'))}
              >
                {theme === 'light' ? <Moon size={24} /> : <Sun size={24} />}
              </Button>
              <span className="avatar" aria-label="Namuna profil: Azizbek Safarov">
                A
              </span>
            </div>
          </header>
          {!route.projectId && !route.invalid && (
            <div className="greeting">
              <h1>Salom, Azizbek</h1>
              <p>Bugun yaxshi g‘oyaga bir qadam yaqinlashing.</p>
            </div>
          )}
          {['invalid', 'unavailable', 'invalid-current', 'recovered', 'conflict'].includes(storageStatus) && (
            <div className="storage-warning">
              <p role="alert">
                {storageStatus === 'conflict'
                  ? 'Boshqa tab saqlangan loyihalarni o‘zgartirdi. Bu tabdagi ish uning ustiga yozilmadi. Avval nusxani yuklab oling, so‘ng sahifani yangilang.'
                  : storageStatus === 'invalid'
                    ? 'Saqlangan loyihalarni o‘qib bo‘lmadi. Asl ma’lumot o‘zgartirilmadi; hozir namuna loyihalari ko‘rsatilmoqda.'
                    : storageStatus === 'recovered'
                      ? 'Yangi o‘zgarishlar saqlandi. Avvalgi o‘qilmagan ma’lumotning zaxira nusxasi ham saqlab qo‘yildi.'
                      : 'Brauzer xotirasiga saqlab bo‘lmadi. O‘zgarishlar faqat bu ochiq sahifada qoladi. Ularni fayl sifatida yuklab olishingiz mumkin.'}
              </p>
              <Button className="outlined" onClick={downloadBackup}>
                Loyihalarni yuklab olish <DownloadIcon size={18} />
              </Button>
            </div>
          )}
          {route.projectId || route.invalid ? (
            selectedProject && !route.invalid ? (
              <ProjectWorkspace
                key={selectedProject.id}
                project={selectedProject}
                view={view}
                onBack={() => navigate(view)}
                onUpdate={updateProject}
                onTask={index => changeTask(selectedProject.id, index)}
                onBookmark={() => toggleSaved(selectedProject.id)}
                onExport={downloadBackup}
                storageStatus={storageStatus}
                onDirtyChange={markDirty}
                Button={Button}
              />
            ) : (
              <section className="workspace-missing">
                <h1 id="project-heading" tabIndex={-1}>
                  Loyiha topilmadi
                </h1>
                <p>
                  Bu manzilga mos loyiha shu brauzerda yo‘q. Havola loyiha ma’lumotini boshqa qurilmaga
                  ko‘chirmaydi.
                </p>
                <Button className="filled" onClick={() => navigate('all')}>
                  Loyihalarga qaytish
                </Button>
              </section>
            )
          ) : (
            <>
              <section className="overview">
                <div className="hero">
                  <div>
                    <span className="hero-label">
                      <Icon name="palette" size={18} /> Sizning ijodiy maydoningiz
                    </span>
                    <h2>
                      G‘oyangizga
                      <br />
                      shakl bering.
                    </h2>
                    <p>Yangi loyiha boshlang. Aniq qadamlar bilan uni tayyor natijaga aylantiring.</p>
                    <div className="hero-actions">
                      <Button className="filled" onClick={startProject}>
                        <Plus size={18} /> Yangi loyiha
                      </Button>
                      <Button
                        className="outlined"
                        onClick={() => {
                          headingRef.current?.scrollIntoView({
                            behavior: reduce ? 'instant' : 'smooth',
                            block: 'start'
                          });
                          headingRef.current?.focus({ preventScroll: true });
                        }}
                      >
                        Loyihalarni ko‘rish
                      </Button>
                    </div>
                  </div>
                  <div className="hero-composition" aria-hidden="true">
                    <motion.div
                      className="shape shape-square"
                      initial={reduce ? false : { opacity: 0, scale: 0.85 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={transition}
                    />
                    <motion.div
                      className="shape shape-circle"
                      initial={reduce ? false : { opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ ...transition, delay: reduce ? 0 : 0.08 }}
                    />
                    <div className="shape shape-arch" />
                    <span className="composition-label">B</span>
                  </div>
                </div>
                <aside className="progress-panel">
                  <div className="progress-label">
                    <CheckCheck size={24} /> Qadamlaringiz
                  </div>
                  <strong>
                    {totalPercent}
                    <span>%</span>
                  </strong>
                  <p>
                    {checkedTasks} / {totalTasks} qadam bajarildi
                  </p>
                  <md-linear-progress value={totalPercent / 100} aria-label="Umumiy loyiha progressi" />
                  <div className="progress-counts">
                    <span>
                      <b>{projects.length}</b>loyiha
                    </span>
                    <span>
                      <b>{done}</b>3/3 belgilangan
                    </span>
                    <span>
                      <b>{saved}</b>saqlangan
                    </span>
                  </div>
                </aside>
              </section>
              <div className="workspace-header">
                <h2 ref={headingRef} tabIndex={-1} id="projects-heading">
                  {
                    { all: 'Loyihalaringiz', saved: 'Saqlangan loyihalar', done: 'Bajarilgan loyihalar' }[
                      view
                    ]
                  }
                </h2>
                <div className="view-switch" role="group" aria-label="Ko‘rinish">
                  {[
                    { id: 'list', icon: List, label: 'Ro‘yxat ko‘rinishi' },
                    { id: 'grid', icon: LayoutGrid, label: 'Karta ko‘rinishi' }
                  ].map(item => (
                    <button
                      type="button"
                      key={item.id}
                      className={`view-segment ${display === item.id ? 'chosen' : ''}`}
                      aria-label={item.label}
                      title={item.label}
                      aria-pressed={display === item.id}
                      onClick={() => setDisplay(item.id)}
                    >
                      <md-ripple />
                      {display === item.id && <Check size={16} />}
                      <item.icon size={20} />
                    </button>
                  ))}
                </div>
              </div>
              <div className="toolbar">
                <md-chip-set className="filters" aria-label="Loyiha yo‘nalishlari">
                  {categories.map(c => (
                    <Button
                      key={c}
                      onClick={event => {
                        if (category === c) event.preventDefault();
                        else setCategory(c);
                      }}
                      aria-pressed={category === c}
                      className={`filter ${category === c ? 'selected' : ''}`}
                    >
                      {c}
                    </Button>
                  ))}
                </md-chip-set>
                <md-outlined-select
                  className="sort"
                  value={sort}
                  quick={reduce}
                  onchange={e => setSort(e.target.value)}
                  aria-label="Loyihalarni saralash"
                >
                  <md-select-option value="recent">
                    <div slot="headline">Yangi qo‘shilgan</div>
                  </md-select-option>
                  <md-select-option value="name">
                    <div slot="headline">Nom bo‘yicha</div>
                  </md-select-option>
                </md-outlined-select>
              </div>
              <section className="projects-section" aria-labelledby="projects-heading">
                {display === 'list' && filtered.length > 0 && (
                  <div className="list-heading" aria-hidden="true">
                    <span>Loyiha nomi</span>
                    <span>Yo‘nalish</span>
                    <span>Bajarilgan</span>
                    <span />
                  </div>
                )}
                <div className={`project-grid ${display === 'list' ? 'project-list' : ''}`}>
                  <AnimatePresence mode="popLayout" initial={false}>
                    {filtered.map(project => (
                      <motion.article
                        layout={reduce ? false : 'position'}
                        className={`project-card ${project.tone}`}
                        key={project.id}
                        initial={{ opacity: 0, y: reduce ? 0 : 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, scale: reduce ? 1 : 0.98 }}
                        transition={transition}
                      >
                        <div className="card-name">
                          <span className="file-icon">
                            <ProjectIcon category={project.category} />
                          </span>
                          <h3>
                            <button
                              className="project-title-button"
                              data-project-id={project.id}
                              onClick={event => openProject(event, project.id)}
                            >
                              {project.title}
                            </button>
                          </h3>
                          <Button
                            className={`icon-button save ${project.saved ? 'saved' : ''}`}
                            onClick={() => toggleSaved(project.id)}
                            aria-label={`${project.title}: ${project.saved ? 'saqlanganlardan olish' : 'saqlash'}`}
                            aria-pressed={project.saved}
                          >
                            <Bookmark size={24} fill={project.saved ? 'currentColor' : 'none'} />
                          </Button>
                        </div>
                        <Button
                          className="preview-open"
                          data-project-id={project.id}
                          onClick={event => openProject(event, project.id)}
                          aria-label={`${project.title} loyihasini ochish`}
                        >
                          <Art
                            kind={project.art}
                            title={project.title}
                            description={project.description}
                            category={project.category}
                          />
                          <span className="preview-open-label" aria-hidden="true">
                            <ArrowUpRight size={22} />
                          </span>
                        </Button>
                        <div className="project-category">{project.category}</div>
                        <p className="project-description">{project.description}</p>
                        <div className="project-progress">
                          <span className={progress(project) === 1 ? 'complete' : ''}>
                            {progress(project) === 1 && <Check size={14} />}{' '}
                            {project.tasks.filter(t => t.done).length} / 3 qadam
                          </span>
                          <md-linear-progress
                            className="mini-progress"
                            value={progress(project)}
                            aria-label={`${project.title} progressi`}
                          />
                        </div>
                        {display === 'list' && (
                          <Button
                            className="row-open icon-button"
                            onClick={event => openProject(event, project.id)}
                            aria-label={`${project.title} loyihasini ochish`}
                          >
                            <ChevronRight size={20} />
                          </Button>
                        )}
                      </motion.article>
                    ))}
                  </AnimatePresence>
                </div>
                {filtered.length === 0 && (
                  <motion.div
                    className="empty-state"
                    initial={{ opacity: 0, y: reduce ? 0 : 12 }}
                    animate={{ opacity: 1, y: 0 }}
                  >
                    <span>
                      <FolderOpen size={40} />
                    </span>
                    <h3>
                      {query
                        ? 'Hech narsa topilmadi'
                        : view === 'done'
                          ? 'Bajarilgan loyihalar shu yerda'
                          : view === 'saved'
                            ? 'Saqlangan loyihalar shu yerda'
                            : 'Bu yo‘nalishda hali loyiha yo‘q'}
                    </h3>
                    <p>
                      {query
                        ? 'Boshqa so‘z bilan qidiring yoki filtrlarni tozalang.'
                        : view === 'saved'
                          ? 'Loyiha kartasidagi saqlash belgisini bosing.'
                          : view === 'done'
                            ? 'Loyihadagi uchta qadamni bajaring va belgilang.'
                            : 'Yangi loyihangizni shu yo‘nalishda boshlang.'}
                    </p>
                    <Button className="filled" onClick={() => navigate('all')}>
                      Barcha loyihalarni ko‘rish
                    </Button>
                  </motion.div>
                )}
                <p className="results-status" role="status" aria-live="polite">
                  {filtered.length} ta loyiha{query ? ` · “${query}” uchun` : ''}
                </p>
              </section>
            </>
          )}
          <footer>
            <span>Bloom · Material Design 3</span>
            <a href="https://material-web.dev/" target="_blank" rel="noopener">
              Rasmiy M3 komponentlari <ExternalLink size={16} />
            </a>
          </footer>
        </main>
      </div>
      <Modal
        open={createOpen}
        onOpenChange={setCreateOpen}
        title="Yangi loyiha"
        description={
          ['unavailable', 'invalid-current', 'conflict'].includes(storageStatus)
            ? 'Hozir faqat shu tabda ishlaysiz. Yangi loyiha nusxasini faylga yuklab oling.'
            : 'Yangi loyiha yarating. Saqlash imkoni bo‘lsa shu brauzerda qoladi; xatoda ogohlantiramiz.'
        }
        opener={createOpener}
      >
        <form
          key={formVersion}
          onSubmit={submitProject}
          onInput={() => setFormError('')}
          className="project-form"
          noValidate
        >
          <md-outlined-text-field
            autofocus
            id="project-title"
            name="title"
            label="Loyiha nomi"
            aria-label="Loyiha nomi"
            maxLength={80}
            required
            error={!!formError}
            error-text={formError}
          />
          <md-outlined-text-field
            type="textarea"
            id="project-description"
            name="description"
            label="Qisqa g‘oya"
            aria-label="Qisqa g‘oya"
            rows={3}
            maxLength={200}
          />
          <md-outlined-select
            id="project-category"
            name="category"
            label="Yo‘nalish"
            aria-label="Yo‘nalish"
            quick={reduce}
          >
            <md-select-option selected value="Ta’lim">
              <div slot="headline">Ta’lim</div>
            </md-select-option>
            {categories.slice(2).map(c => (
              <md-select-option key={c} value={c}>
                <div slot="headline">{c}</div>
              </md-select-option>
            ))}
          </md-outlined-select>
          {formError && (
            <p className="sr-only" id="form-error" role="alert">
              {formError}
            </p>
          )}
          <div className="form-actions">
            <Button className="text" onClick={() => setCreateOpen(false)}>
              Bekor qilish
            </Button>
            <Button type="submit" className="filled">
              Loyihani yaratish <Plus size={18} />
            </Button>
          </div>
        </form>
      </Modal>
      <Modal
        open={helpOpen}
        onOpenChange={setHelpOpen}
        title="Bloom haqida"
        description="Material Design 3 komponentlari bilan yaratilgan mustaqil loyiha maydoni."
        opener={helpOpener}
      >
        <div className="help-copy">
          <p>
            Yangi loyiha yarating, uchta qadamni belgilang va yoqqan loyihalarni saqlang. Qidiruv, filtrlar va
            saralash birgalikda ishlaydi.
          </p>
          <p>
            Ma’lumotlar faqat shu brauzer xotirasida qoladi. Profil va boshlang‘ich loyihalar namuna. Serverga
            ma’lumot yuborilmaydi.
          </p>
          <p>
            Loyiha kartasini ochsangiz alohida ish maydoniga o‘tasiz. Nomi, izohi va uch qadamini tahrirlash
            mumkin. Ichki havola va brauzerning Orqaga tugmasi ishlaydi. Havola ma’lumotni boshqa qurilmaga
            ko‘chirmaydi; nusxani JSON fayliga yuklab oling.
          </p>
          <Button className="outlined" onClick={downloadBackup}>
            Loyihalarni yuklab olish <DownloadIcon size={18} />
          </Button>
          <p>
            Tugmalar, maydonlar, checkboxlar, filtrlar va dialoglar rasmiy Material Web komponentlaridan
            foydalanadi. Ranglar Google Material Color Utilities bilan hosil qilinadi. Operatsion tizimda
            harakatni kamaytirish yoqilsa, katta harakatlar o‘chadi.
          </p>
          <a href="https://m3.material.io/styles/motion/overview/how-it-works" target="_blank" rel="noopener">
            Google Material motion qo‘llanmasi <ExternalLink size={15} />
          </a>
        </div>
      </Modal>
      <Modal
        open={paletteOpen}
        onOpenChange={setPaletteOpen}
        title="O‘zingizga mos rang"
        description="Tugmalar va faol belgilar rangini tanlang."
        opener={paletteOpener}
        className="palette-modal"
        actions={
          <Button className="filled" onClick={() => setPaletteOpen(false)}>
            Tayyor <Check size={18} />
          </Button>
        }
      >
        <div className="palette-options" role="radiogroup" aria-label="Asosiy rang">
          {SEEDS.map((item, index) => (
            <label
              key={item.color}
              className="palette-option"
              data-selected={seed === item.color}
              htmlFor={`palette-${index}`}
            >
              <span className="palette-swatch" style={{ background: item.color }} aria-hidden="true" />
              <span className="palette-name">
                {item.label}
                <small>{seed === item.color ? 'Tanlangan' : 'Tanlash'}</small>
              </span>
              <md-radio
                role="radio"
                aria-checked={String(seed === item.color)}
                id={`palette-${index}`}
                name="palette"
                value={item.color}
                checked={seed === item.color}
                aria-label={item.label}
                onchange={event => {
                  if (event.target.checked) setSeed(item.color);
                }}
              />
            </label>
          ))}
        </div>
        <div className="palette-samples">
          <h3>Sahifadagi ko‘rinishi</h3>
          <dl className="palette-preview">
            <div>
              <dt>Asosiy tugma</dt>
              <dd className="sample-primary" />
            </div>
            <div>
              <dt>Sahifa foni</dt>
              <dd className="sample-surface" />
            </div>
            <div>
              <dt>Oddiy panel</dt>
              <dd className="sample-panel" />
            </div>
          </dl>
        </div>
      </Modal>
      <AnimatePresence>
        {toast && (
          <motion.div
            className="snackbar"
            role="status"
            initial={{ opacity: 0, y: reduce ? 0 : 25, scale: reduce ? 1 : 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: reduce ? 0 : 12 }}
          >
            <svg
              aria-hidden="true"
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <circle cx="12" cy="12" r="9" />
              <path d="M12 11v6M12 7v1" />
            </svg>
            <span>{toast}</span>
            <Button className="icon-button" aria-label="Xabarni yopish" onClick={() => setToast('')}>
              <X size={18} />
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
    </MotionConfig>
  );
}
createRoot(document.getElementById('root')).render(<App />);
