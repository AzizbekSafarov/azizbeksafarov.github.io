export const categories = ['Hammasi', 'Ta’lim', 'Dizayn', 'Texnologiya'];
export const initialProjects = [
  {
    id: 'kasb',
    title: 'Kasb yo‘lingizni toping',
    description: 'Yoshlar uchun kasblar va o‘quv imkoniyatlarini bir joyga jamlaymiz.',
    category: 'Ta’lim',
    tone: 'blue',
    art: 'orbit',
    saved: false,
    tasks: [
      { text: 'Asosiy g‘oyani yozish', done: true },
      { text: 'Mobil maketni tayyorlash', done: false },
      { text: 'Ishlaydigan sahifani tekshirish', done: false }
    ]
  },
  {
    id: 'brand',
    title: 'G‘oyaga yangi ko‘rinish',
    description: 'Rang, tipografika va shakllar bilan o‘ziga xos brend yarating.',
    category: 'Dizayn',
    tone: 'peach',
    art: 'flower',
    saved: true,
    tasks: [
      { text: 'Ranglar palitrasini tanlash', done: false },
      { text: 'Tipografik iyerarxiyani yaratish', done: false },
      { text: 'Komponentlarni tekshirish', done: false }
    ]
  },
  {
    id: 'ai',
    title: 'AI bilan bir qadam',
    description: 'Kundalik ishlarni yengillashtiradigan sodda yordamchi ilova.',
    category: 'Texnologiya',
    tone: 'green',
    art: 'spark',
    saved: false,
    tasks: [
      { text: 'Foydalanuvchi ehtiyojini aniqlash', done: true },
      { text: 'Asosiy oqimni yaratish', done: true },
      { text: 'Natijani sinovdan o‘tkazish', done: false }
    ]
  },
  {
    id: 'portfolio',
    title: 'Ishlaringiz so‘zlasin',
    description: 'Eng yaxshi loyihalaringiz uchun tiniq va tartibli portfolio.',
    category: 'Dizayn',
    tone: 'lavender',
    art: 'stack',
    saved: false,
    tasks: [
      { text: 'Loyihalarni saralash', done: true },
      { text: 'Sahifalarni yig‘ish', done: true },
      { text: 'Taqdimotni tekshirish', done: true }
    ]
  }
];
export function progress(project) {
  return project.tasks.filter(task => task.done).length / project.tasks.length;
}
export function validateProjects(value) {
  if (!Array.isArray(value) || value.length > 200) return null;
  const ids = new Set();
  for (const p of value) {
    if (
      !p ||
      typeof p.id !== 'string' ||
      !p.id.trim() ||
      ids.has(p.id) ||
      typeof p.title !== 'string' ||
      !p.title.trim() ||
      p.title.length > 80 ||
      typeof p.description !== 'string' ||
      p.description.length > 200 ||
      !categories.slice(1).includes(p.category) ||
      !['blue', 'peach', 'green', 'lavender'].includes(p.tone) ||
      !['orbit', 'flower', 'spark', 'stack'].includes(p.art) ||
      typeof p.saved !== 'boolean' ||
      !Array.isArray(p.tasks) ||
      p.tasks.length !== 3 ||
      p.tasks.some(
        t =>
          !t ||
          typeof t.text !== 'string' ||
          !t.text.trim() ||
          t.text.length > 200 ||
          typeof t.done !== 'boolean'
      )
    )
      return null;
    ids.add(p.id);
  }
  return value;
}
export function normalizeSearch(text) {
  return text
    .toLocaleLowerCase('uz')
    .normalize('NFKC')
    .replace(/[‘’ʻʼ`´]/g, "'")
    .trim();
}
export function visibleProjects(
  projects,
  { view = 'all', category = 'Hammasi', query = '', sort = 'recent' } = {}
) {
  const normalized = normalizeSearch(query);
  const filtered = projects.filter(
    p =>
      (view !== 'saved' || p.saved) &&
      (view !== 'done' || progress(p) === 1) &&
      (category === 'Hammasi' || p.category === category) &&
      normalizeSearch(`${p.title} ${p.description} ${p.category}`).includes(normalized)
  );
  return sort === 'name' ? [...filtered].sort((a, b) => a.title.localeCompare(b.title, 'uz')) : filtered;
}
export function createProject({ title, description, category }, id) {
  const cleanTitle = title.trim(),
    cleanDescription = description.trim();
  if (
    !cleanTitle ||
    cleanTitle.length > 80 ||
    cleanDescription.length > 200 ||
    !categories.slice(1).includes(category)
  )
    throw new Error('Invalid project');
  const visual = {
    'Ta’lim': ['blue', 'orbit'],
    Dizayn: ['peach', 'flower'],
    Texnologiya: ['green', 'spark']
  }[category];
  return {
    id,
    title: cleanTitle,
    description: cleanDescription || 'Yangi g‘oyani ishlaydigan loyihaga aylantiring.',
    category,
    tone: visual[0],
    art: visual[1],
    saved: false,
    tasks: [
      { text: 'G‘oyani aniq yozish', done: false },
      { text: 'Birinchi variantni yaratish', done: false },
      { text: 'Natijani tekshirish', done: false }
    ]
  };
}

export function updateProjectDetails(project, draft) {
  if (
    !draft ||
    typeof draft.title !== 'string' ||
    typeof draft.description !== 'string' ||
    !Array.isArray(draft.tasks) ||
    draft.tasks.length !== 3 ||
    draft.tasks.some(t => typeof t !== 'string')
  )
    throw new Error('Invalid project details');
  const next = {
    ...project,
    title: draft.title.trim(),
    description: draft.description.trim(),
    tasks: project.tasks.map((task, index) => ({ ...task, text: draft.tasks[index].trim() }))
  };
  if (!validateProjects([next])) throw new Error('Invalid project details');
  return next;
}
