# Qabul tekshiruvi — Bloom · Material Design 3

Bajarilgan deb faqat amalda tekshirilgan band belgilanadi.

- [ ] Yangi loyiha → bo‘sh forma xatosi → haqiqiy yozishda xato yo‘qolishi → muvaffaqiyat → keyingi forma toza.
- [ ] Qidiruv + kategoriya + saralash + saqlangan/bajarilgan bo‘limlar; takror bosilgan chip tanlangan qoladi.
- [ ] Karta/ro‘yxat, bookmark, detail uch checkbox → progress → reload.
- [ ] Palitra label/ArrowRight/Space → bitta radio; light/dark; qisqa oynada Tayyor doim ko‘rinadi.
- [ ] Escape → opener; filtrdan yo‘qolgan karta uchun fokus loyiha sarlavhasiga qaytadi.
- [ ] Haqiqiy biletning har majburiy talabi natijagacha ishlaydi.
- [ ] Bo‘sh/noto‘g‘ri qiymat va topilmagan natija tushunarli.
- [ ] 320/390, 768, 1024, 1440 px: yozuv va asosiy tugmalar kesilmaydi.
- [ ] Tugma oddiy paneldan farqlanadi; hover/pressed/focus va tanlangan holat ko‘rinadi.
- [ ] Tab, Enter/Space va Escape; dialog yopilgach fokus qaytadi.
- [ ] Tegishli storage reload’dan keyin to‘g‘ri; boshqa ma’lumot tozalanmagan.
- [ ] Ishlashga ta’sir qiladigan console error va resurs 404lari qolmagan.
- [ ] Kerakli source test/build o‘tdi; yangi build ko‘rsatilmoqda.
- [ ] Fake statistika/yuborish/to‘lov haqiqiy deb taqdim etilmagan.
- [ ] HANDOFF.md, run yo‘riqnomasi va qisqa himoya izohi yangilangan.

| Talab | Amal | Kod joyi | Tekshiruv | Natija / ochiq xato |
|---|---|---|---|---|
| Biletdan to‘ldiriladi | | | | Tekshirilmagan |
