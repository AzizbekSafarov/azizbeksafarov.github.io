# Lola — portable competition starter

## Boshlash

AI uchun: AGENTS.md → AI-BRIEF.md → CURRENT-TASK.md → HANDOFF.md. Bilet hali bu paketga yozilmagan. Kod `site/` papkasida. Internet/shablon ruxsati tanlovdagi amaldagi tartibga bog‘liq.

## Oldindan yig‘ilgan nusxa, npm o‘rnatmasdan

```text
node serve.mjs
```

Brauzer: http://127.0.0.1:8080/ . Server faqat 127.0.0.1’da ishlaydi. Port band bo‘lsa PowerShell’da `$env:PORT=8081; node serve.mjs`. Ctrl+C bilan to‘xtatiladi.

Node bo‘lmasa Python:

```text
python -m http.server 8080 --bind 127.0.0.1 --directory site
```

Python preview manzili: http://127.0.0.1:8080/07-lola.html

## Tahrirlash

Shaxsiy tanlov nusxasida `site/07-lola.html`, `shared.css`, `shared.js` va sahifa ishlatadigan scriptlarni tahrirlang. Paketda umumiy resurs va sahifalar orasidagi havolalar saqlanishi uchun 9 HTML namuna ham bor. Npm shart emas. Original generatorlarni ishga tushirish direct tahrirni qayta yozadi; tanlov nusxasi va kutubxona manbasini aralashtirmang.

CHECKLIST.md bilan sinang. HANDOFF.md ga haqiqiy natijalarni yozing. Namuna statistika, profil, narxlar, formalar va datasetlar haqiqiy xizmat emas. Tashqi CDN runtime’da kerak emas; fonts/licenses ZIP ichida. To‘liq tanlov tadqiqoti barcha dizaynlar paketi `kit.zip` ichida va https://azizbeksafarov.github.io/ustoz/ai.md da.
