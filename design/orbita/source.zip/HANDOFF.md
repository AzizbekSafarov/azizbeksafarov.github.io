# HANDOFF — Orbita

## Snapshot
- Manba: https://azizbeksafarov.github.io/design/orbita/
- Paket sanasi: 2026-11-03; source fingerprint: 7cb555556102d076ecd81dfeb26c97e387b8083f96f602d5917e11ec44672621
- Holat: oldindan tayyorlangan demo. Hozirgi biletga moslashtirish hali bajarilmagan.
- Baseline QA: ZIP ichidagi site/QA-REPORT.md; Kengaytirilgan tekshiruv: /design/QA-EXPANDED.md. Har bir paket o‘z model va kombinatsiya testlarini olib yuradi; markaziy event-fixture sinovlari faqat to‘liq repoda. Bu yangi o‘zgarishlar uchun avtomatik dalil emas.

## Hozirgi topshiriq
- Bilet: CURRENT-TASK.md ga yoziladi.
- Qolgan vaqt va ishdagi local URL: hali kiritilmagan.
- Bajarilgan talablar: hali kiritilmagan.
- O‘zgargan fayllar: hali kiritilmagan.
- O‘tkazilgan testlar va natija: hali kiritilmagan.
- Ochiq xato / cheklov: demo browser-local; haqiqiy backend/yuborish yo‘q.
- Keyingi amal: biletni talab → amal → qabul sinovi jadvaliga ajratish.

## Keyingi AIga topshirish
Keyingi AI: `AGENTS.md` dagi tartib bilan o‘qiydi — bilet, shu fayl, `AI-BRIEF.md`, tanlov qoidalari, so‘ng tegishli source. Tekshirilmagan bandni bajarilgan deb belgilama; har katta bosqichdan keyin shu faylni yangila.
