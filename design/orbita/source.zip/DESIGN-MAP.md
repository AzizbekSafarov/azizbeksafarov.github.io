# Orbita — dizayn xaritasi

Foydalanuvchi kod yozmaydi va o‘zgarishni oddiy so‘z bilan aytadi. Bu fayl o‘sha so‘zni aniq fayl va amalga bog‘laydi. Qiymatlar shu paketdagi haqiqiy fayllardan olingan.

## Kimning so‘zi ustun

1. Foydalanuvchining aniq aytgani (rang, shrift, joylashuv, bo‘lim, matn) vizual kontraktdan ustun: darhol bajaring, “dizaynni saqlash kerak” deb rad etmang.
2. Bilet talabi va joydagi tashkilotchi ko‘rsatmasi hech qachon buzilmaydi; zid bo‘lsa, buni bir jumlada ayting va qaror so‘rang.
3. Aytilmagan hamma narsada shu dizaynning shrift, rang roli va tugma uslubi saqlanadi. Vizual kontrakt tasodifiy buzilishdan himoya qiladi, foydalanuvchini cheklamaydi.
4. O‘zgarishni butun saytga izchil qo‘llang: bitta tokenni o‘zgartirib, unga bog‘liq matn kontrasti (kamida 4.5:1), hover va tanlangan holatlarni ham tekshiring.

Build kerak emas: faylni saqlab, brauzerni yangilash yetarli.

## Foydalanuvchi aytsa

| So‘z | Qayerda | Nima qilinadi |
|---|---|---|
| “Rangni o‘zgartir”, “ko‘kroq qil” | “Asosiy ranglar” jadvali, `site/style.css` | Token yetmaydi: ko‘p rang to‘g‘ridan-to‘g‘ri yozilgan. Jadvaldagi qiymatni ko‘rsatilgan fayllarda birga almashtiring, keyin kontrastni tekshiring |
| “Shriftni almashtir”, “kattaroq yoz” | `site/style.css`, `@font-face` | Yangi shriftni loyihaga lokal qo‘shing; o‘lchamni sarlavha va matn darajalari bo‘yicha o‘zgartiring |
| “Matnni o‘zgartir”, “sarlavha boshqacha bo‘lsin” | `site/index.html`, `site/model.js` | Boshlang‘ich matn sahifada, takrorlanadigan kartalar ma’lumotda |
| “Rasmni almashtir” | `site/ (yangi `images/` papkasini oching)` | Faylni almashtiring, alt matnini yangilang, litsenziyani `CREDITS.md` ga yozing |
| “Yangi bo‘lim”, “yangi sahifa qo‘sh” | `site/index.html`, `site/app.js`, `site/layout.css` | Mavjud bo‘lim naqshidan foydalaning, navigatsiyaga ulang, responsive holatini qo‘shing |
| “Bu bo‘limni olib tashla” | `site/index.html`, `site/app.js` | Bo‘limni, unga havolani va ishlatilmay qolgan kodni birga olib tashlang |
| “Forma qo‘sh”, “tekshiruv bo‘lsin” | `site/model.js`, `site/app.js` | Qoidani modelga, xabarni ekranga yozing; bo‘sh va noto‘g‘ri qiymatni sinang |
| “Saqlansin”, “yangilaganda yo‘qolmasin” | `site/app.js` | Storage kaliti versiyasi bilan saqlang, reload va boshqa tabda sinang |
| “Telefonda buzilyapti” | `site/layout.css` | 390, 768 va 1366 px da ko‘ring, sababini tuzating |
| “Butunlay boshqa kayfiyat” | `site/style.css`, `site/layout.css` | Avval tokenlar va shriftlarni o‘zgartiring; freymvorkni almashtirmang |
| “Hakam shu joyni o‘zgartirishni so‘radi” | yuqoridagi qatorlar | Eng kichik xavfsiz tahrirni qiling, shu oqimni qayta sinang (`ZAXIRA/JONLI-OZGARISH.md`) |

## Fayllar

| Fayl | Qator | Vazifasi |
|---|---|---|
| `site/app.js` | 154 | tugmalar, dialoglar, saqlash va eksport |
| `site/index.html` | 122 | sahifa tuzilishi, bo‘limlar va boshlang‘ich matn |
| `site/layout.css` | 524 | sahifa joylashuvi, responsive va holatlar |
| `site/model.js` | 38 | namuna ma’lumotlar, tekshiruv va hisob-kitob |
| `site/style.css` | 271 | rang tokenlari, shriftlar va komponentlar |

## Rang tokenlari

| Token | Hozirgi qiymat |
|---|---|
| `--ink` | `#e6eef0` |
| `--line` | `#294046` |
| `--modal` | `#102024` |
| `--focus` | `#b1f56a` |

## Asosiy ranglar

Kodda eng ko‘p ishlatilgan to‘g‘ridan-to‘g‘ri qiymatlar. Rang o‘zgarishi saytda ko‘rinishi uchun shu qiymatlarni almashtiring.

| Rang | Marta | Fayllar |
|---|---|---|
| `#b1f56a` | 14 | layout.css |
| `#294046` | 10 | layout.css |
| `#ffffff` | 5 | index.html, layout.css, style.css |
| `#ff6b35` | 3 | index.html |
| `#6e969d` | 3 | layout.css |
| `#071215` | 2 | index.html, layout.css |
| `#e6eef0` | 2 | layout.css |
| `#426166` | 2 | layout.css |
| `#111111` | 2 | style.css |
| `#487ba8` | 1 | index.html |
| `#183a57` | 1 | index.html |
| `#090e16` | 1 | index.html |
| `#444b57` | 1 | index.html |
| `#91b4cc` | 1 | index.html |

## Shriftlar

- Flight Display — `fonts/chakrapetch.ttf`
- Flight Mono — `fonts/mono.ttf`

## Sahifa bo‘limlari

| Teg | id | Tavsif |
|---|---|---|
| `nav` | `—` | Asosiy navigatsiya |
| `main` | `main` |  |
| `section` | `missions` |  |
| `section` | `watchlist` |  |
| `nav` | `—` | Qo‘shimcha havolalar |
