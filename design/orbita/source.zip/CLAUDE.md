# Project context

@AGENTS.md

If the import above is not supported, read `AGENTS.md` in this folder first; it holds the reading order and working rules. Talk to the user in Uzbek.
