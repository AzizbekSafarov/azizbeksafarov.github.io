# CURRENT-TASK.md — joriy tanlov loyihasi

Yangilangan vaqt: [haqiqiy vaqt va timezone]
Biletning asl matni: [foydalanuvchi/ekspert bergan matn]
Qolgan vaqt: [taxmin qilma]
Joydagi talab va ruxsatlar: [tasdiqlangan tartib]
Tanlangan dizayn: [bitta slug va source manzili]
Asosiy foydalanuvchi va muammo: [...]
Asosiy oqim: [boshlanish → amal → saqlangan natija]
Qabul mezonlari: [...]

## Sahifalar va foydalanuvchi yo‘li
Landing/ochiq mazmun: [maqsad, CTA va biletga mos sahifalar]
Animatsiya: [nimani tushuntiradi; pause/reduced-motion/fallback]
Dashboard/kabinet: [o‘z holati va davom ettirish; kerak bo‘lsa]
Workspace: [asosiy yaratish/tahrirlash → saqlash → natija]
Route → kirish huquqi → asosiy amal → data manbasi → loading/empty/error: [...]
Saqlanmagan tahrir va deep link/reload xulqi: [...]

## Muhim sifat talablari
Shu vazifaga tatbiq etiladigan bandlar va sababi: [...]
UI/accessibility, ruxsat va ma’lumot saqlanishi dalili: [...]
Nosozlik/retry, kuzatuv, tezlik va foydalanish xarajati chegarasi: [...]
Migration/backup/restore va deploy/rollback yo‘li: [...]
Holat: [tekshirildi / ochiq muammo / hali tekshirilmadi / tatbiq etilmaydi + sabab]

## Joriy texnik qaror
- Hosting: [lokal/statik yoki bilet talab qilgan server; haqiqiy manzil yoki hali yaratilmagan]
- Monitoring: UptimeRobot — [haqiqiy holat]
- Backend: [talab qilinmaydi yoki Supabase; holati va sababi, secret yozma]
- Google OAuth: [client/redirect sozlanganmi; secret yozma]
- AI: [provayder, model, limit bo‘yicha tasdiqlangan fakt]
- Telegram: [webhook va test holati; token/shaxsiy chat ID yozma]

## Vazifa doirasi
Hozir bajariladi: [...]
Keyinga qoldiriladi: [...]
O‘zgartirishdan oldin foydalanuvchi qarori kerak: [...]

## Haqiqiy holat
Ishlaydi va tekshirildi: [dalil + vaqt]
Qisman bajarilgan: [...]
Reja: [...]
Noma’lum: [...]
Keyingi aniq amal: [...]

Parol, token, CVV, karta raqami yoki haqiqiy .env bu faylga yozilmaydi. Fayl joriy loyiha ichida yuritiladi; uni ommaviy .io’ga avtomatik yuborish ruxsati yo‘q.
