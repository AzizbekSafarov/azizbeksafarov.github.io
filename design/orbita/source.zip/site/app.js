import { data, normalize } from './model.js?v=b317a166d7';
const SLUG = 'orbita';
const $ = s => document.querySelector(s),
  $$ = s => [...document.querySelectorAll(s)];
const storageKey = SLUG + '-state-v1';
let memory = [],
  persistent = true;
function read() {
  if (!persistent) return memory;
  try {
    const raw = localStorage.getItem(storageKey),
      parsed = raw === null ? [] : JSON.parse(raw);
    if (!Array.isArray(parsed)) throw Error('Invalid stored list');
    memory = normalize(parsed);
    return memory;
  } catch {
    persistent = false;
    $('#status').textContent =
      'Saqlangan ma’lumot o‘qilmadi. Asl nusxa o‘zgartirilmaydi; yangi tanlov faqat shu tabda qoladi.';
    return memory;
  }
}
function commit(ids) {
  memory = normalize(ids);
  if (!persistent) return memory;
  try {
    localStorage.setItem(storageKey, JSON.stringify(memory));
  } catch {
    persistent = false;
    $('#status').textContent =
      'Saqlash cheklangan. Tanlov faqat shu ochiq tabda qoladi; sahifani yangilashda yo‘qolishi mumkin.';
  }
  return memory;
}
function toggle(id) {
  const ids = read();
  return commit(ids.includes(id) ? ids.filter(x => x !== id) : [...ids, id]);
}
function download(name, text, type = 'text/plain;charset=utf-8') {
  const url = URL.createObjectURL(new Blob(['\ufeff' + text], { type })),
    a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}
let opener, openedId;
function openDialog(button) {
  opener = button;
  openedId = button.dataset.read;
  $('#reader').showModal();
}
$$('[data-close]').forEach(b => b.addEventListener('click', () => $('#reader').close()));
$('#reader')?.addEventListener('close', () => {
  const target = opener?.isConnected
    ? opener
    : document.querySelector('[data-read="' + openedId + '"]') || $('#saved-toggle');
  target?.focus();
});
window.addEventListener('storage', e => {
  if (e.key === storageKey || e.key === null) {
    const active = document.activeElement;
    const attribute = ['data-save', 'data-read', 'data-lesson'].find(a => active?.hasAttribute(a));
    const value = attribute ? active.getAttribute(attribute) : null;
    render();
    if ($('#reader')?.open && typeof syncSave === 'function') syncSave();
    if (attribute && !active.isConnected) {
      const next = $$('[' + attribute + ']').find(b => b.getAttribute(attribute) === value && !b.disabled);
      const target = next || $('#saved-toggle') || $('#lesson-title');
      if (target) {
        if (!next && target.id === 'lesson-title') target.setAttribute('tabindex', '-1');
        target.focus({ preventScroll: true });
      }
    }
  }
});
let selected = 'iss';
function render() {
  const p = data.find(p => p.id === selected),
    ids = read();
  $$('[data-mission]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.mission === selected)));
  $('#mission-title').textContent = p.name;
  $('#mission-tag').textContent = p.tag;
  $('#mission-text').textContent = p.text;
  $('#mission-facts').innerHTML = p.facts.map(([a, b]) => `<div><dt>${a}</dt><dd>${b}</dd></div>`).join('');
  $('#mission-source').href = p.source;
  $('#mission-code').textContent = p.tag;
  const on = ids.includes(selected);
  $('#mission-save').setAttribute('aria-pressed', on);
  $('#mission-save').textContent = on ? '✓ Kuzatuvda' : 'Kuzatuvga qo‘shish +';
  $('#saved-count').textContent = ids.length;
  $('#watch-empty').hidden = !!ids.length;
  $('#watch-items').innerHTML = ids.map(id => `<li>${data.find(p => p.id === id).name}</li>`).join('');
  $('#export').disabled = !ids.length;
  $('#satellite text').textContent = p.id.toUpperCase();
  const mode = {
    iss: { x: 540, y: 150, r: 122 },
    webb: { x: 580, y: 310, r: 75 },
    voyager: { x: 600, y: 85, r: 40 }
  }[p.id];
  $('#orbit-title').textContent = p.name + ' — shartli chizma, masshtabga mos emas';
  $('.orbit-display').dataset.mission = p.id;
  $('#motion-toggle').disabled = p.id !== 'iss';
  $('#motion-toggle').textContent =
    p.id !== 'iss'
      ? 'Bu chizma statik'
      : document.body.classList.contains('paused')
        ? 'Harakatni davom ettirish ▶'
        : 'Harakatni to‘xtatish Ⅱ';
  $$('#satellite circle').forEach(c => {
    c.setAttribute('cx', mode.x);
    c.setAttribute('cy', mode.y);
  });
  $('#satellite path').setAttribute('d', `M${mode.x + 18} ${mode.y}h50`);
  $('#satellite text').setAttribute('x', mode.x + 20);
  $('#satellite text').setAttribute('y', mode.y - 18);
  $('.orbit-display>svg>circle').setAttribute('r', mode.r);
}
$$('[data-mission]').forEach(b =>
  b.addEventListener('click', () => {
    selected = b.dataset.mission;
    render();
  })
);
$('#mission-save').addEventListener('click', () => {
  toggle(selected);
  render();
});
$('#export').addEventListener('click', () =>
  download(
    'orbita-atlas.txt',
    'ORBITA — kuzatuv ro‘yxati\n' +
      read()
        .map(id => {
          const p = data.find(p => p.id === id);
          return p.name + '\n' + p.source;
        })
        .join('\n\n')
  )
);
$('#motion-toggle').addEventListener('click', e => {
  const paused = document.body.classList.toggle('paused');
  syncMotion();
  e.currentTarget.setAttribute('aria-pressed', paused);
  e.currentTarget.textContent = paused ? 'Harakatni davom ettirish ▶' : 'Harakatni to‘xtatish Ⅱ';
});
function syncMotion() {
  document.querySelector('#satellite').style.animationPlayState =
    document.hidden || document.body.classList.contains('paused') ? 'paused' : '';
}
document.addEventListener('visibilitychange', syncMotion);
render();
