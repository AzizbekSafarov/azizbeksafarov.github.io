# Hozirgi tanlov topshirig‘i

- Biletning aynan matni: hali berilmagan.
- Foydalanuvchi va maqsad: biletdan olinadi.
- Majburiy funksiyalar: biletdan olinadi.
- Amaliy ish uchun haqiqiy qolgan vaqt: hali kiritilmagan.
- Joydagi vosita/internet/shablon talablari: tasdiqlanganini yozing.
- Tanlangan dizayn: Hisob
- Server, login yoki baza: biletda talab qilinsa yozing (reja: ARCHITECTURE.md); yaratilgan xizmat va URLlar shu yerga.

Kengroq shakl kerak bo‘lsa: PROJECT-TASK-TEMPLATE.md.
