import { data, normalize, report, csv } from './model.js?v=d5b2701a45';
const SLUG = 'hisob';
const $ = s => document.querySelector(s),
  $$ = s => [...document.querySelectorAll(s)];
const storageKey = SLUG + '-state-v1';
let memory = [],
  persistent = true;
function read() {
  if (!persistent) return memory;
  try {
    const raw = localStorage.getItem(storageKey),
      parsed = raw === null ? [] : JSON.parse(raw);
    if (!Array.isArray(parsed)) throw Error('Invalid stored list');
    memory = normalize(parsed);
    return memory;
  } catch {
    persistent = false;
    $('#status').textContent =
      'Saqlangan ma’lumot o‘qilmadi. Asl nusxa o‘zgartirilmaydi; yangi tanlov faqat shu tabda qoladi.';
    return memory;
  }
}
function commit(ids) {
  memory = normalize(ids);
  if (!persistent) return memory;
  try {
    localStorage.setItem(storageKey, JSON.stringify(memory));
  } catch {
    persistent = false;
    $('#status').textContent =
      'Saqlash cheklangan. Tanlov faqat shu ochiq tabda qoladi; sahifani yangilashda yo‘qolishi mumkin.';
  }
  return memory;
}
function toggle(id) {
  const ids = read();
  return commit(ids.includes(id) ? ids.filter(x => x !== id) : [...ids, id]);
}
function download(name, text, type = 'text/plain;charset=utf-8') {
  const url = URL.createObjectURL(new Blob(['\ufeff' + text], { type })),
    a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}
let opener, openedId;
function openDialog(button) {
  opener = button;
  openedId = button.dataset.read;
  $('#reader').showModal();
}
$$('[data-close]').forEach(b => b.addEventListener('click', () => $('#reader').close()));
$('#reader')?.addEventListener('close', () => {
  const target = opener?.isConnected
    ? opener
    : document.querySelector('[data-read="' + openedId + '"]') || $('#saved-toggle');
  target?.focus();
});
window.addEventListener('storage', e => {
  if (e.key === storageKey || e.key === null) {
    const active = document.activeElement;
    const attribute = ['data-save', 'data-read', 'data-lesson'].find(a => active?.hasAttribute(a));
    const value = attribute ? active.getAttribute(attribute) : null;
    render();
    if ($('#reader')?.open && typeof syncSave === 'function') syncSave();
    if (attribute && !active.isConnected) {
      const next = $$('[' + attribute + ']').find(b => b.getAttribute(attribute) === value && !b.disabled);
      const target = next || $('#saved-toggle') || $('#lesson-title');
      if (target) {
        if (!next && target.id === 'lesson-title') target.setAttribute('tabindex', '-1');
        target.focus({ preventScroll: true });
      }
    }
  }
});
let period = 7,
  query = '',
  sort = 'total',
  direction = -1;
function render() {
  const r = report(period, query, sort, direction),
    maximum = Math.ceil(Math.max(...r.series) / 30) * 30;
  $('#metric-total').textContent = String(r.total).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  $('#metric-change').textContent =
    (((r.total - r.previous) / r.previous) * 100).toFixed(1).replace('.', ',') + '%';
  $('#period-label').textContent = period + ' kun · namunaviy davr';
  const responsivePlotWidth = Math.max(260, Math.round($('#chart').clientWidth));
  $('#chart').setAttribute('viewBox', `0 0 ${responsivePlotWidth} 245`);
  $('#chart')
    .querySelector('g[stroke] path')
    .setAttribute('d', [25, 85, 145, 205].map(y => `M45 ${y}H${responsivePlotWidth - 10}`).join(''));
  const points = r.series.map((v, i) => [
    45 + (i * (responsivePlotWidth - 55)) / 6,
    205 - (v / maximum) * 180
  ]);
  $('#chart-line').setAttribute('d', 'M' + points.map(p => p.join(',')).join(' L'));
  $('#chart-area').setAttribute(
    'd',
    'M45,205 L' + points.map(p => p.join(',')).join(' L') + ` L${responsivePlotWidth - 10},205Z`
  );
  $('#chart-dots').innerHTML = points.map(([x, y]) => `<circle cx="${x}" cy="${y}" r="4"/>`).join('');
  $('#chart-labels').innerHTML =
    [0, 1, 2, 3]
      .map(i => `<text x="35" y="${209 - i * 60}" text-anchor="end">${Math.round((maximum * i) / 3)}</text>`)
      .join('') +
    points
      .map(
        ([x, y], i) =>
          `<text x="${x}" y="235" text-anchor="${i === points.length - 1 ? 'end' : 'middle'}">${period === 7 ? i + 1 : Math.round(((i + 1) * 30) / 7)}-kun</text>`
      )
      .join('');
  $('#chart-title').textContent = period + ' kunlik namuna: ' + r.series.join(', ');
  $('#chart-summary').textContent = '7 ta davr bo‘lagi: ' + r.series.join(' / ') + ' · jami ' + r.total;
  $('#rows').innerHTML = r.rows.length
    ? r.rows
        .map(
          p =>
            `<tr><th scope="row">${p.name}</th><td>${p.total}</td><td>${((p.total / r.total) * 100).toFixed(1).replace('.', ',')}%</td><td>${p.previous}</td></tr>`
        )
        .join('')
    : '<tr><td colspan="4">Hudud topilmadi. Qidiruvni o‘zgartiring.</td></tr>';
  $('#result-count').textContent =
    r.rows.length +
    ' / ' +
    data.length +
    ' hudud · CSV faqat shu qatorlarni oladi. Yuqoridagi jami va grafik barcha hududlar bo‘yicha.';
  $('#export').disabled = !r.rows.length;
  $$('[data-sort]').forEach(b => {
    const active = b.dataset.sort === sort;
    b.closest('th').setAttribute(
      'aria-sort',
      active ? (direction === 1 ? 'ascending' : 'descending') : 'none'
    );
    b.textContent =
      (b.dataset.sort === 'name' ? 'Hudud' : 'Ishtiroklar') +
      ' ' +
      (active ? (direction === 1 ? '↑' : '↓') : '↕');
  });
}
$$('[data-period]').forEach(b =>
  b.addEventListener('click', () => {
    period = Number(b.dataset.period);
    $$('[data-period]').forEach(x => x.setAttribute('aria-pressed', x === b));
    render();
  })
);
$('#search').addEventListener('input', e => {
  query = e.target.value;
  render();
});
$$('[data-sort]').forEach(b =>
  b.addEventListener('click', () => {
    direction = sort === b.dataset.sort ? -direction : 1;
    sort = b.dataset.sort;
    render();
  })
);
$('#export').addEventListener('click', () =>
  download(
    'hisob-' + period + '-kun.csv',
    csv(report(period, query, sort, direction).rows),
    'text/csv;charset=utf-8'
  )
);
render();

let chartObservedWidth = 0;
new ResizeObserver(entries => {
  const width = Math.round(entries[0].contentRect.width);
  if (width !== chartObservedWidth) {
    chartObservedWidth = width;
    render();
  }
}).observe(document.querySelector('.chart'));
