# Forma — paketni ochish

Bu paketda tanlangan **Forma** dizayni (`site/`), tanlov hujjatlari, Codex qo‘llanmasi va AI’siz zaxira to‘plami (`ZAXIRA/`) bor. AI uchun ish qoidalari va o‘qish tartibi — `AGENTS.md`.

## Uch qadam

1. `node verify-package.mjs` — fayllar to‘liq va o‘zgarmaganini tekshiradi (asl holat uchun; tahrirdan keyin hash tabiiy ravishda o‘zgaradi).
2. `node serve.mjs` — namunani http://127.0.0.1:8080/ da ochadi. Npm kerak emas.
3. AI’ga biletni bering yoki `CURRENT-TASK.md` ga yozing.

Kod yozmasdan Codex bilan shu starterda ishlash: `ZAXIRA/CODEX.md`. AI ishlamay qolsa yoki limit tugasa — AI’siz yo‘l: `ZAXIRA/ZAXIRA.md` (skelet va kodsiz panel). Himoyada matn, rang yoki elementni o‘zgartirish: `ZAXIRA/JONLI-OZGARISH.md`.

## Fayllar

| Fayl | Nima uchun |
|---|---|
| `AGENTS.md` | AI uchun ish qoidalari va o‘qish tartibi (`CLAUDE.md`, `GEMINI.md` shunga yo‘naltiradi) |
| `CURRENT-TASK.md`, `HANDOFF.md` | Bilet va bajarilgan ish — loyiha davomida to‘ldiriladi |
| `AI-BRIEF.md` | Shu dizayn: vizual kontrakt, fayl xaritasi, ishga tushirish, saqlanadigan oqimlar |
| `SCREENS.json` | Tayyor ekranlar, holatlar va hali qurilmagan qismlar; source to‘liqligi bilan mahsulot to‘liqligini ajratadi |
| `CHECKLIST.md` | Qabul tekshiruvi |
| `COMPETITION.md`, `CURRENT-COMPETITION.md`, `SCORING-WORKPLAN.md` | Tanlov qoidalari, oxirgi tekshiruv, mezon → ish → dalil |
| `REGULATIONS.md` | Uch nizom hujjati, 39 sahifa, to‘liq |
| `FULL-COMPETITION-CONTEXT.md` | Barcha yig‘ilgan tadqiqot (01–07 manbalar bo‘lim sifatida) |
| `WORKFLOW.md`, `ARCHITECTURE.md`, `API-GUIDE.md` | Ish usuli, mahsulot tuzilishi va server rejasi (faqat bilet talab qilsa) |
| `PREPARATION.md`, `READING-PLAN.json`, `READ-RECEIPT.md` | To‘liq o‘qish xaritasi va qaydi |
| `TASK-BOUNDARY.json` | Qaysi matn bilet hisoblanadi, qaysi biri emas |
| `PACKAGE-MANIFEST.json`, `kit.json` | Fayl hashlari va preview sozlamasi |
