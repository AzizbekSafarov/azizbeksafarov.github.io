# Forma — independent sector identity

Zamonaviy obyekt studiyasi. Manrope 500 asosiy matn, 650 xizmat, 750–800 sarlavha/narx. Oqartirilgan maydon, grafit, material fotosuratlari. Qattiq to‘rtburchak qora savdo tugmalari; aniq rangli savat holati. Ingichka serif, mikro matn, ghost savdo tugmalari va yumaloq sayohat kartalari yo‘q. Asimmetrik fotografik shelf saqlansin; mobil uch buyum ham o‘qiladigan kenglikda. Narx/materiallar namuna, savat lokal.

Standalone HTML/CSS/JavaScript; no npm install. Preview: `python -m http.server 8080 --bind 127.0.0.1` here. Test: `node --test *.test.mjs`.

index.html: markup and IDs. style.css: local fonts and accessible mechanics. layout.css: this sector’s full art direction and responsive rules. app.js: existing flows, storage and focus. model.js: data/validation. Read CREDITS.md and bundled font licenses. Preserve model IDs and validated storage keys when changing layout.

Original library: identity-styles/*.css and identities_v4.py apply last after build_collection.py / build_refined.py. In the isolated competition ZIP, edit runtime files directly. After gallery changes regenerate previews, metadata and build_handoff.py.


At ZIP root run node serve.mjs. Editable files are site/. Read AGENTS.md and AI-BRIEF.md.


## Joriy kontekst
WORKFLOW.md → PROJECT-STATUS.json → ARCHITECTURE.md → API-GUIDE.md. Ehtimoliy xavflar aniqlangan xato emas. Haqiqiy loyiha holati CURRENT-TASK.md va HANDOFF.md’da saqlanadi. Bu hujjatlar backendni avtomatik yaratmaydi.

AI kuchsiz yoki limitli bo‘lsa: ZAXIRA/ZAXIRA.md (qisqa reja, kichik AI so‘rovlari, build’siz zaxira sayt va himoyadagi jonli o‘zgarish qo‘llanmasi).

To‘liq o‘qish: START-HERE.md → PREPARATION.md → READING-PLAN.json. Qisqa brif to‘liq hujjatni almashtirmaydi.
