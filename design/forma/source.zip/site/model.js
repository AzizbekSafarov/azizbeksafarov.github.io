export const products = [
  {
    id: 'rattan',
    name: 'To‘qima stul',
    category: 'mebel',
    label: 'Mebel',
    image: 'chair.jpg',
    alt: 'Oq fonda tabiiy rangli, to‘qima orqa suyanchiqli stul',
    price: 1290000,
    material: 'Yog‘och / to‘qima',
    size: '62 × 70 × 78 sm',
    description:
      'O‘qish burchagi yoki sokin suhbat uchun tabiiy teksturali aksent. To‘qima suyanchiq va och rangli karkas yengil taassurot beradi.',
    care: 'Yumshoq quruq mato bilan arting. Namlik va to‘g‘ridan-to‘g‘ri kuchli quyoshdan asrang.'
  },
  {
    id: 'luma',
    name: 'Luma stol chirog‘i',
    category: 'yoruglik',
    label: 'Yorug‘lik',
    image: 'lamp.jpg',
    alt: 'Yumshoq yorug‘lik taratayotgan klassik stol chirog‘i',
    price: 420000,
    material: 'Metall / mato',
    size: 'Ø 30 × 48 sm',
    description:
      'Kechki muhitga mo‘ljallangan yumshoq yorug‘lik g‘oyasi. Yon stol yoki komod ustida interyerga iliqlik qo‘shadi.',
    care: 'Tozalashdan oldin elektrdan uzing. Abajurni quruq yumshoq cho‘tka bilan tozalang.'
  },
  {
    id: 'terra',
    name: 'Terra vaza',
    category: 'dekor',
    label: 'Dekor',
    image: 'vase.jpg',
    alt: 'Yog‘och stol ustidagi oq, vertikal teksturali vaza',
    price: 180000,
    material: 'Keramika',
    size: 'Ø 18 × 26 sm',
    description:
      'Soddalashtirilgan shakl va vertikal tekstura. Bitta shox yoki ixcham kompozitsiya bilan javon va stolga mos tushadi.',
    care: 'Yumshoq mato bilan arting. Ichki sirlanish va suvga chidamlilikni haqiqiy mahsulotda tekshiring.'
  }
];
export function normalize(value) {
  const out = {};
  if (value && typeof value === 'object' && !Array.isArray(value))
    for (const p of products) {
      const n = value[p.id];
      if (Number.isInteger(n) && n > 0) out[p.id] = Math.min(n, 20);
    }
  return out;
}
export function change(value, id, delta) {
  const next = normalize(value);
  if (!products.some(p => p.id === id) || !Number.isInteger(delta)) return next;
  const n = Math.min(20, (next[id] || 0) + delta);
  if (n <= 0) delete next[id];
  else next[id] = n;
  return next;
}
export function total(value) {
  const cart = normalize(value);
  return products.reduce((sum, p) => sum + (cart[p.id] || 0) * p.price, 0);
}
export const money = n => new Intl.NumberFormat('uz-UZ').format(n) + ' so‘m';
export function exportCart(value) {
  const cart = normalize(value);
  return (
    'FORMA — TANLANGAN BUYUMLAR\n\n' +
    products
      .filter(p => cart[p.id])
      .map(p => `${p.name} × ${cart[p.id]} — ${money(p.price * cart[p.id])}`)
      .join('\n') +
    '\n\nJami: ' +
    money(total(cart)) +
    '\nNamuna narxlari va xususiyatlari. Bu buyurtma, to‘lov yoki mavjudlik tasdig‘i emas.\n'
  );
}
