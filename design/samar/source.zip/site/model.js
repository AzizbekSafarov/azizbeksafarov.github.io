export const places = [
  {
    id: 'registan',
    name: 'Registon maydoni',
    tag: 'Me’morchilik',
    minutes: 75,
    image: 'registan.jpg',
    alt: 'Registon maydonidagi uch madrasa va keng hovli',
    intro: 'Uch madrasa. Bitta ulkan taassurot.',
    text: 'Ulug‘bek, Sherdor va Tillakori madrasalari maydon atrofida joylashgan. Naqshlar, peshtoqlar va hovli kompozitsiyasini shoshmasdan kuzatish uchun vaqt ajrating.',
    note: 'Avval umumiy ko‘rinishni tomosha qiling, keyin me’moriy detallarga yaqinlashing.',
    source: 'https://uzbekistan.travel/en/o/registan/',
    map: 'Registan Samarkand'
  },
  {
    id: 'shohi-zinda',
    name: 'Shohi Zinda',
    tag: 'Naqsh va xotira',
    minutes: 60,
    image: 'shohi-zinda.jpg',
    alt: 'Shohi Zinda majmuasining koshinkor peshtoqlari',
    intro: 'Moviy rangning ming xil ohangi.',
    text: 'Maqbaralar ansambli Samarqandning muhim tarixiy maskanlaridan biri. Tor yo‘lak, koshin va yozuvlar majmuaga o‘ziga xos xarakter beradi.',
    note: 'Bu ziyorat maskani. Sokinlikni saqlang, tashrif odobi va joydagi ko‘rsatmalarga rioya qiling.',
    source: 'https://uzbekistan.travel/ru/o/memorialnyj-ansambl-shahi-zinda/',
    map: 'Shah i Zinda Samarkand'
  },
  {
    id: 'guri-amir',
    name: 'Go‘ri Amir',
    tag: 'Temuriylar merosi',
    minutes: 60,
    image: 'guri-amir.jpg',
    alt: 'Go‘ri Amir maqbarasining moviy gumbazi va peshtoqi',
    intro: 'Samarqand osmonidagi moviy gumbaz.',
    text: 'Amir Temur va Temuriylar oilasi a’zolari dafn etilgan maqbara. Gumbaz, tashqi bezak va ichki makon tafsilotlari alohida e’tiborga loyiq.',
    note: 'Tashrifdan oldin ochilish va chipta ma’lumotini rasmiy manba yoki kassadan tekshiring.',
    source: 'https://uzbekistan.travel/en/o/gur-emir/',
    map: 'Gur e Amir Samarkand'
  }
];
export function normalize(value) {
  const raw = value && typeof value === 'object' ? value : {};
  return {
    start: typeof raw.start === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(raw.start) ? raw.start : '09:00',
    ids: [...new Set(Array.isArray(raw.ids) ? raw.ids : [])].filter(id => places.some(p => p.id === id))
  };
}
export function schedule(value) {
  const plan = normalize(value);
  let cursor = Number(plan.start.slice(0, 2)) * 60 + Number(plan.start.slice(3));
  return plan.ids.map((id, index) => {
    const place = places.find(p => p.id === id);
    if (index) cursor += 20;
    const start = cursor;
    cursor += place.minutes;
    return { ...place, start, end: cursor };
  });
}
export function clock(minutes) {
  return `${String(Math.floor(minutes / 60) % 24).padStart(2, '0')}:${String(minutes % 60).padStart(2, '0')}${minutes >= 1440 ? ' (+1 kun)' : ''}`;
}
export function exportPlan(value) {
  const rows = schedule(value);
  return (
    'SAMAR — SHAXSIY KUN REJASI\n\n' +
    (rows.length
      ? rows
          .map((p, i) => `${i + 1}. ${clock(p.start)}–${clock(p.end)} — ${p.name}\n${p.source}`)
          .join('\n\n')
      : 'Manzil tanlanmagan.') +
    '\n\nVaqtlar rejalashtirish uchun taklif. Manzillar orasiga shartli 20 daqiqa qo‘shilgan; haqiqiy yo‘l, tirbandlik va tashrif vaqtini joyida tekshiring. Chipta yoki bron emas.\n'
  );
}
