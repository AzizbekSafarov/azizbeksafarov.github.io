# Samar — AI uchun paketni ochish tartibi

Tanlangan dizayn: samar. Kod: site/. Bu faqat shu dizayn paketi.

Bu fayl mundarija. PREPARATION.md va READING-PLAN.json to‘liq o‘qiladigan manbalarni sanaydi; READ-RECEIPT.md o‘qilganlikni halol qayd qilish uchun bo‘sh shablon. START-HERE yoki AI-BRIEF bilan cheklanib to‘liq o‘qidim demang.

1. Joriy foydalanuvchi bileti, CURRENT-TASK.md va HANDOFF.md holatini tekshir. PREPARATION.md’ni o‘qi.
2. CURRENT-COMPETITION.md / CURRENT-COMPETITION-FACTS.json, so‘ng AGENTS.md, AI-BRIEF.md, WORKFLOW.md va PROJECT-STATUS.json ni o‘qi.
3. COMPETITION.md va SCORING-WORKPLAN.md ni o‘qi; qabul sinovi hamda himoya dalilini talablar bilan bog‘la. Tafsilotdagi 21 mezon loyiha tahriridan, amaldagi reglament ustuvor.
4. ARCHITECTURE.md / API-GUIDE.md va faqat tanlangan source fayllarini o‘qi.
5. To‘liq tadqiqot FULL-COMPETITION-CONTEXT.md’da; uch hujjatning qisqartirilmagan 39 sahifasi REGULATIONS.md’da. To‘liq o‘qish so‘ralsa bo‘limlarni to‘liq o‘qi; o‘qilmaganini ochiq ayt. Qisqa kirish matni to‘liq manba o‘rniga o‘tmaydi.

01-RESEARCH.md, 02-WORKFLOW.md, 03-STATISTICS.csv, 04-VIDEO-POSTER.md, 05-SOURCES.md va 07-FACTS.json deb tilga olingan tarixiy manbalar FULL-COMPETITION-CONTEXT.md ichida nomlangan bo‘limlar sifatida to‘liq mavjud. 06-SCORE-WORKPLAN.md alohida SCORING-WORKPLAN.md sifatida ham berilgan. Asl PDF nusxalari havolalari to‘liq manbalar bo‘limida; ularni bu ZIPdagi alohida PDF fayl deb taxmin qilma.

## Paketni tekshirish va ishga tushirish

Avval `node verify-package.mjs`: PACKAGE-MANIFEST.json’dagi hajm va SHA-256 bo‘yicha fayllar tekshiriladi. Bu original snapshot uchun; keyingi o‘zingiz kiritgan tahrir tabiiy ravishda hashni o‘zgartiradi. Haqiqiy kalitlarni paketga qo‘shma.

`node serve.mjs` mavjud namunani http://127.0.0.1:8080/ da ochadi. Source build/test tafsiloti README.md va site/README.md’da. Bloom source buildi uchun npm paketlari kerak, tayyor dist preview uchun npm shart emas.
